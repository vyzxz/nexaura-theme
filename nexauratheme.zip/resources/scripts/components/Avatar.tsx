import React from 'react';
import BoringAvatar, { AvatarProps } from 'boring-avatars';
import { useStoreState } from '@/state/hooks';
import styled from 'styled-components/macro';
import tw from 'twin.macro';

// --- Sector 07 Biometric Palette ---
// Swapped to high-contrast Cyans and Matrix-style greens
const palette = ['#06b6d4', '#22d3ee', '#0891b2', '#155e75', '#0e7490'];

const AvatarContainer = styled.div`
    ${tw`relative inline-block overflow-hidden rounded-lg border border-white/10 transition-all duration-300 group-hover:border-cyan-500/50` };
    background: rgba(0, 0, 0, 0.4);
    
    /* Scanning line overlay */
    &::after {
        content: "";
        ${tw`absolute inset-0 pointer-events-none opacity-20` };
        background: linear-gradient(
            rgba(6, 182, 212, 0) 0%,
            rgba(6, 182, 212, 0.2) 50%,
            rgba(6, 182, 212, 0) 100%
        );
        background-size: 100% 4px;
    }
`;

type Props = Omit<AvatarProps, 'colors'>;

const _Avatar = ({ variant = 'pixel', ...props }: AvatarProps) => (
    <AvatarContainer>
        <BoringAvatar 
            colors={palette} 
            variant={variant === 'beam' ? 'pixel' : variant} // Force pixel for HUD feel
            {...props} 
            square // Sector 07 uses squared/slightly rounded shapes
        />
    </AvatarContainer>
);

const _UserAvatar = ({ variant = 'pixel', ...props }: Omit<Props, 'name'>) => {
    const uuid = useStoreState((state) => state.user.data?.uuid);

    return (
        <AvatarContainer>
            <BoringAvatar 
                colors={palette} 
                name={uuid || 'system'} 
                variant={variant === 'beam' ? 'pixel' : variant} 
                {...props} 
                square
            />
        </AvatarContainer>
    );
};

_Avatar.displayName = 'Avatar';
_UserAvatar.displayName = 'Avatar.User';

const Avatar = Object.assign(_Avatar, {
    User: _UserAvatar,
});

export default Avatar;