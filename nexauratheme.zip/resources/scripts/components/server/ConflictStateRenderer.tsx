import React from 'react';
import { ServerContext } from '@/state/server';
import ScreenBlock from '@/components/elements/ScreenBlock';
import ServerInstallSvg from '@/assets/images/server_installing.svg';
import ServerErrorSvg from '@/assets/images/server_error.svg';
import ServerRestoreSvg from '@/assets/images/server_restore.svg';
import styled, { keyframes } from 'styled-components/macro';
import tw from 'twin.macro';

const glitch = keyframes`
    0% { transform: translate(0); }
    20% { transform: translate(-2px, 2px); }
    40% { transform: translate(-2px, -2px); }
    60% { transform: translate(2px, 2px); }
    80% { transform: translate(2px, -2px); }
    100% { transform: translate(0); }
`;

const StatusBadge = styled.div<{ $color: string }>`
    ${tw`inline-flex items-center px-3 py-1 rounded-lg border mb-4` };
    ${tw`text-[10px] font-black uppercase tracking-[0.2em]` };
    background: rgba(255, 255, 255, 0.03);
    
    /* Dynamic border/text colors based on system state */
    border-color: ${props => props.$color === 'red' ? 'rgba(239, 68, 68, 0.2)' : props.$color === 'yellow' ? 'rgba(245, 158, 11, 0.2)' : 'rgba(6, 182, 212, 0.2)'};
    color: ${props => props.$color === 'red' ? '#f87171' : props.$color === 'yellow' ? '#fbbf24' : '#22d3ee'};
`;

const GlitchTitle = styled.h1`
    ${tw`text-4xl font-black uppercase tracking-tighter text-white mb-2` };
    &:hover {
        animation: ${glitch} 0.3s cubic-bezier(.25,.46,.45,.94) both infinite;
    }
`;

// Helper component to inject JSX into the String-only ScreenBlock
const SectorScreenWrapper = ({ title, message, image, code, color = 'cyan' }: any) => (
    <div css={tw`relative`}>
        {/* Pass empty strings to core ScreenBlock to hide its default text rendering and satisfy TS */}
        <ScreenBlock
            title={""} 
            image={image}
            message={""} 
        />
        
        {/* Overlay our Sector 07 HUD elements */}
        <div css={tw`absolute inset-0 flex flex-col items-center justify-center pointer-events-none`}>
            <div css={tw`mt-[14rem] flex flex-col items-center pointer-events-auto`}>
                <StatusBadge $color={color}>
                    System_Code // {code}
                </StatusBadge>
                
                <GlitchTitle>{title.replace(/ /g, '_')}</GlitchTitle>
                
                <p css={tw`max-w-md mx-auto text-neutral-400 font-mono text-[10px] uppercase tracking-[0.2em] leading-loose text-center mt-4 px-4`}>
                    {message.replace(/ /g, '_')}
                </p>
                
                {/* Decorative terminal bracket */}
                <div css={tw`mt-6 flex items-center gap-2 opacity-20`}>
                    <div css={tw`w-8 h-[1px] bg-white`} />
                    <span css={tw`text-[8px] text-white font-mono`}>END_TRANSMISSION</span>
                    <div css={tw`w-8 h-[1px] bg-white`} />
                </div>
            </div>
        </div>
    </div>
);

export default () => {
    const status = ServerContext.useStoreState((state) => state.server.data?.status || null);
    const isTransferring = ServerContext.useStoreState((state) => state.server.data?.isTransferring || false);
    const isNodeUnderMaintenance = ServerContext.useStoreState(
        (state) => state.server.data?.isNodeUnderMaintenance || false
    );

    if (status === 'installing' || status === 'install_failed' || status === 'reinstall_failed') {
        return (
            <SectorScreenWrapper
                code="PROC_INSTALL"
                title="Building Node"
                image={ServerInstallSvg}
                message="Your server environment is being provisioned. Please stand by for initialization."
            />
        );
    }

    if (status === 'suspended') {
        return (
            <SectorScreenWrapper
                code="AUTH_LOCKOUT"
                color="red"
                title="Access Denied"
                image={ServerErrorSvg}
                message="This server has been decommissioned or suspended. Administrative action required."
            />
        );
    }

    if (isNodeUnderMaintenance) {
        return (
            <SectorScreenWrapper
                code="NODE_OFFLINE"
                color="yellow"
                title="Maintenance"
                image={ServerErrorSvg}
                message="The physical host is undergoing hardware calibration. Expected downtime is minimal."
            />
        );
    }

    return (
        <SectorScreenWrapper
            code={isTransferring ? 'DATA_MIGRATE' : 'FS_RECOVER'}
            title={isTransferring ? 'Transferring' : 'Restoring'}
            image={ServerRestoreSvg}
            message={
                isTransferring
                    ? "Migrating server data to a new high-performance node. Telemetry will resume shortly."
                    : "Reconstructing file system from secure backup archives. Operation in progress."
            }
        />
    );
};