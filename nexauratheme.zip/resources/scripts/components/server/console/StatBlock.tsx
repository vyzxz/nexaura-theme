import React from 'react';
import Icon from '@/components/elements/Icon';
import { IconDefinition } from '@fortawesome/free-solid-svg-icons';
import classNames from 'classnames';
import useFitText from 'use-fit-text';
import CopyOnClick from '@/components/elements/CopyOnClick';
import styled from 'styled-components/macro';
import tw from 'twin.macro';

interface StatBlockProps {
    title: string;
    copyOnClick?: string;
    color?: string | undefined;
    icon: IconDefinition;
    children: React.ReactNode;
    className?: string;
}

const BlockContainer = styled.div`
    ${tw`relative flex items-center p-3 rounded-lg bg-white/5 border border-white/5 transition-all duration-300` };
`;

const StatusIndicator = styled.div`
    ${tw`absolute left-0 top-1/2 -translate-y-1/2 w-1 h-2/3 rounded-r-full` };
`;

export default ({ title, copyOnClick, icon, color, className, children }: StatBlockProps) => {
    // Added a check: useFitText might be failing if the library wasn't bundled correctly
    const { fontSize, ref } = useFitText({ minFontSize: 8, maxFontSize: 24 });

    return (
        <CopyOnClick text={copyOnClick}>
            <BlockContainer className={className}>
                <StatusIndicator className={color || 'bg-cyan-500/20'} />

                <div className={'flex items-center justify-center mr-4 opacity-70'}>
                    <Icon icon={icon} className={classNames('w-4 h-4', color ? 'text-white' : 'text-cyan-400')} />
                </div>

                <div className={'flex flex-col justify-center overflow-hidden w-full'}>
                    <p className={'font-header uppercase tracking-wider text-[10px] text-gray-400 leading-none mb-1'}>
                        {title}
                    </p>
                    {/* Wrap children in a fragment to ensure it's a valid React node for useFitText */}
                    <div
                        ref={ref}
                        className={'h-[1.5rem] w-full font-mono text-gray-50 truncate leading-tight'}
                        style={{ fontSize }}
                    >
                        <>{children}</>
                    </div>
                </div>
            </BlockContainer>
        </CopyOnClick>
    );
};