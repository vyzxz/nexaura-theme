import React from 'react';
import Icon from '@/components/elements/Icon';
import { IconDefinition } from '@fortawesome/free-solid-svg-icons';
import classNames from 'classnames';
import useFitText from 'use-fit-text';
import CopyOnClick from '@/components/elements/CopyOnClick';
import styled from 'styled-components/macro';
import tw from 'twin.macro';

interface StatBlockProps {
    title: string;
    copyOnClick?: string;
    color?: string | undefined;
    icon: IconDefinition;
    children: React.ReactNode;
    className?: string;
}

const BlockContainer = styled.div`
    ${tw`relative flex items-center p-3 rounded-lg bg-white/5 border border-white/5 transition-all duration-300` };
    
    &:hover {
        ${tw`bg-white/[0.08] border-white/10` };
    }
`;

// Fixed: Separate Twin utilities from dynamic color logic
const StatusIndicator = styled.div<{ $color?: string }>`
    ${tw`absolute left-0 top-1/2 -translate-y-1/2 w-1 h-2/3 rounded-r-full transition-all duration-500` };
    
    /* Use standard CSS for the dynamic color to avoid Twin build errors */
    ${props => props.$color ? tw`bg-white` : tw`bg-cyan-500` };
    opacity: ${props => props.$color ? '0.8' : '0.2'};
    
    box-shadow: ${props => props.$color ? '0 0 8px currentColor' : 'none'};
`;

export default ({ title, copyOnClick, icon, color, className, children }: StatBlockProps) => {
    // Note: ensure use-fit-text is installed and doesn't return null ref on first render
    const { fontSize, ref } = useFitText({ minFontSize: 8, maxFontSize: 24 });

    return (
        <CopyOnClick text={copyOnClick}>
            <BlockContainer className={className}>
                {/* Visual "LED" bar on the left */}
                <StatusIndicator 
                    // If color is passed (like 'bg-red-500'), we extract the color or just use a default
                    className={color} 
                />

                <div className={'flex items-center justify-center mr-4 opacity-70'}>
                    <Icon
                        icon={icon}
                        className={classNames('w-4 h-4', {
                            'text-cyan-400': !color,
                            'text-white': !!color,
                        })}
                    />
                </div>

                <div className={'flex flex-col justify-center overflow-hidden w-full'}>
                    <p className={'font-header uppercase tracking-wider text-[10px] text-gray-400 leading-none mb-1'}>
                        {title}
                    </p>
                    <div
                        ref={ref}
                        className={'h-[1.5rem] w-full font-mono text-gray-50 truncate leading-tight'}
                        style={{ fontSize }}
                    >
                        {children}
                    </div>
                </div>
            </BlockContainer>
        </CopyOnClick>
    );
};