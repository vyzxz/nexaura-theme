import React, { useEffect, useMemo, useState } from 'react';
import {
    faClock,
    faCloudDownloadAlt,
    faCloudUploadAlt,
    faHdd,
    faMemory,
    faMicrochip,
    faWifi,
} from '@fortawesome/free-solid-svg-icons';
import { bytesToString, ip, mbToBytes } from '@/lib/formatters';
import { ServerContext } from '@/state/server';
import { SocketEvent, SocketRequest } from '@/components/server/events';
import UptimeDuration from '@/components/server/UptimeDuration';
import StatBlock from '@/components/server/console/StatBlock';
import useWebsocketEvent from '@/plugins/useWebsocketEvent';
import classNames from 'classnames';
import { capitalize } from '@/lib/strings';
import styled from 'styled-components/macro';
import tw from 'twin.macro';

type Stats = Record<'memory' | 'cpu' | 'disk' | 'uptime' | 'rx' | 'tx', number>;

// Sector 07 Styled Container for the sidebar stats
const StatsWrapper = styled.div`
    ${tw`flex flex-col gap-3 p-4 bg-black/40 rounded-lg border border-white/5 backdrop-blur-md` };
    box-shadow: inset 0 0 20px rgba(6, 182, 212, 0.03);
`;

const getBackgroundColor = (value: number, max: number | null): string | undefined => {
    const delta = !max ? 0 : value / max;
    if (delta > 0.8) {
        return delta > 0.9 ? 'bg-red-500/80 shadow-[0_0_10px_rgba(239,68,68,0.3)]' : 'bg-yellow-500/80';
    }
    return undefined;
};

const Limit = ({ limit, children }: { limit: string | null; children: React.ReactNode }) => (
    <div className={'flex items-baseline overflow-hidden'}>
        <span className={'truncate font-mono'}>{children}</span>
        <span className={'ml-1 text-cyan-500/30 text-[70%] select-none'}>/ {limit || <>&infin;</>}</span>
    </div>
);

const ServerDetailsBlock = ({ className }: { className?: string }) => {
    const [stats, setStats] = useState<Stats>({ memory: 0, cpu: 0, disk: 0, uptime: 0, tx: 0, rx: 0 });

    const status = ServerContext.useStoreState((state) => state.status.value);
    const connected = ServerContext.useStoreState((state) => state.socket.connected);
    const instance = ServerContext.useStoreState((state) => state.socket.instance);
    const limits = ServerContext.useStoreState((state) => state.server.data!.limits);

    const textLimits = useMemo(() => ({
        cpu: limits?.cpu ? `${limits.cpu}%` : null,
        memory: limits?.memory ? bytesToString(mbToBytes(limits.memory)) : null,
        disk: limits?.disk ? bytesToString(mbToBytes(limits.disk)) : null,
    }), [limits]);

    const allocation = ServerContext.useStoreState((state) => {
        const match = state.server.data!.allocations.find((allocation) => allocation.isDefault);
        return !match ? 'n/a' : `${match.alias || ip(match.ip)}:${match.port}`;
    });

    useEffect(() => {
        if (!connected || !instance) return;
        instance.send(SocketRequest.SEND_STATS);
    }, [instance, connected]);

    useWebsocketEvent(SocketEvent.STATS, (data) => {
        let stats: any = {};
        try {
            stats = JSON.parse(data);
        } catch (e) {
            return;
        }

        setStats({
            memory: stats.memory_bytes,
            cpu: stats.cpu_absolute,
            disk: stats.disk_bytes,
            tx: stats.network.tx_bytes,
            rx: stats.network.rx_bytes,
            uptime: stats.uptime || 0,
        });
    });

    return (
        <StatsWrapper className={className}>
            <StatBlock icon={faWifi} title={'Address'} copyOnClick={allocation}>
                <span className={'truncate font-mono text-xs'}>{allocation}</span>
            </StatBlock>
            
            <StatBlock
                icon={faClock}
                title={'Uptime'}
                color={getBackgroundColor(status === 'running' ? 0 : status !== 'offline' ? 9 : 10, 10)}
            >
                {status === null ? (
                    'Offline'
                ) : stats.uptime > 0 ? (
                    <UptimeDuration uptime={stats.uptime / 1000} />
                ) : (
                    capitalize(status)
                )}
            </StatBlock>

            <StatBlock icon={faMicrochip} title={'CPU Load'} color={getBackgroundColor(stats.cpu, limits.cpu)}>
                {status === 'offline' ? (
                    <span className={'text-gray-500'}>Offline</span>
                ) : (
                    <Limit limit={textLimits.cpu}>{stats.cpu.toFixed(2)}%</Limit>
                )}
            </StatBlock>

            <StatBlock
                icon={faMemory}
                title={'Memory'}
                color={getBackgroundColor(stats.memory / 1024, limits.memory * 1024)}
            >
                {status === 'offline' ? (
                    <span className={'text-gray-500'}>Offline</span>
                ) : (
                    <Limit limit={textLimits.memory}>{bytesToString(stats.memory)}</Limit>
                )}
            </StatBlock>

            <StatBlock icon={faHdd} title={'Disk'} color={getBackgroundColor(stats.disk / 1024, limits.disk * 1024)}>
                <Limit limit={textLimits.disk}>{bytesToString(stats.disk)}</Limit>
            </StatBlock>

            <div className={'grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-white/5'}>
                <StatBlock icon={faCloudDownloadAlt} title={'Inbound'} className={'!bg-transparent !p-0'}>
                    <span className={'text-[10px] font-mono'}>{status === 'offline' ? '0B' : bytesToString(stats.rx)}</span>
                </StatBlock>
                <StatBlock icon={faCloudUploadAlt} title={'Outbound'} className={'!bg-transparent !p-0'}>
                    <span className={'text-[10px] font-mono'}>{status === 'offline' ? '0B' : bytesToString(stats.tx)}</span>
                </StatBlock>
            </div>
        </StatsWrapper>
    );
};

export default ServerDetailsBlock;