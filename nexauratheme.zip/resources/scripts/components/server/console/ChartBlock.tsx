import React from 'react';
import classNames from 'classnames';
import styled, { keyframes } from 'styled-components/macro';
import tw from 'twin.macro';

interface ChartBlockProps {
    title: string;
    legend?: React.ReactNode;
    children: React.ReactNode;
}

const scan = keyframes`
    0% { transform: translateY(-100%); opacity: 0; }
    50% { opacity: 0.5; }
    100% { transform: translateY(100%); opacity: 0; }
`;

const ChartContainer = styled.div`
    ${tw`relative overflow-hidden transition-all duration-300` };
    background: rgba(255, 255, 255, 0.02);
    border: 1px solid rgba(255, 255, 255, 0.05);
    border-radius: 8px;

    &:hover {
        background: rgba(255, 255, 255, 0.04);
        border-color: rgba(6, 182, 212, 0.3);
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.4);
    }

    /* Decorative Scanline Effect */
    &::after {
        content: '';
        ${tw`absolute inset-0 pointer-events-none` };
        background: linear-gradient(to bottom, transparent, rgba(6, 182, 212, 0.05), transparent);
        animation: ${scan} 4s linear infinite;
    }
`;

const TerminalHeader = styled.div`
    ${tw`flex items-center justify-between px-4 py-3 border-b border-white/5` };
    background: rgba(0, 0, 0, 0.2);
`;

const Title = styled.h3`
    ${tw`text-[10px] font-black uppercase tracking-[0.2em] text-neutral-500 transition-colors duration-300` };
    
    .group:hover & {
        ${tw`text-cyan-400` };
    }
`;

export default ({ title, legend, children }: ChartBlockProps) => (
    <ChartContainer className="group">
        <TerminalHeader>
            <div className="flex items-center gap-2">
                {/* Decorative status dot */}
                <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 shadow-[0_0_8px_rgba(6,182,212,0.6)] animate-pulse" />
                <Title>{title.replace(/ /g, '_')}</Title>
            </div>
            
            {legend && (
                <div className="text-[9px] font-mono text-neutral-500 flex items-center gap-3">
                    {legend}
                </div>
            )}
        </TerminalHeader>

        <div className="relative z-10 p-2">
            {children}
        </div>

        {/* Decorative corner accents */}
        <div className="absolute top-0 right-0 w-2 h-2 border-t border-r border-white/10" />
        <div className="absolute bottom-0 left-0 w-2 h-2 border-b border-l border-white/10" />
    </ChartContainer>
);