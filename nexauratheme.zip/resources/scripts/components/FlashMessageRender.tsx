import React from 'react';
import MessageBox from '@/components/MessageBox';
import { useStoreState } from 'easy-peasy';
import tw from 'twin.macro';
import styled, { keyframes } from 'styled-components/macro';
import { ApplicationStore } from '@/state';

type Props = Readonly<{
    byKey?: string;
    className?: string;
}>;

// Custom Sector-07 Entrance Animation
const slideIn = keyframes`
    from {
        opacity: 0;
        transform: translateY(-8px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
`;

const MessageStack = styled.div`
    ${tw`flex flex-col gap-3 w-full` };
    animation: ${slideIn} 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards;
`;

const FlashMessageRender = ({ byKey, className }: Props) => {
    const flashes = useStoreState((state: ApplicationStore) =>
        state.flashes.items.filter((flash) => (byKey ? flash.key === byKey : true))
    );

    if (!flashes.length) {
        return null;
    }

    return (
        <MessageStack className={className}>
            {flashes.map((flash) => (
                <MessageBox 
                    key={flash.id || `${flash.type}-${flash.message}`} 
                    type={flash.type} 
                    title={flash.title}
                >
                    {flash.message}
                </MessageBox>
            ))}
        </MessageStack>
    );
};

export default FlashMessageRender;