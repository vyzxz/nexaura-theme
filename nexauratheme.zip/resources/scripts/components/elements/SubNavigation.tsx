import styled from 'styled-components/macro';
import tw from 'twin.macro';

const SubNavigation = styled.div`
    ${tw`w-full overflow-x-auto transition-all duration-300` };
    background: rgba(15, 15, 15, 0.4);
    backdrop-filter: blur(8px);
    border-bottom: 1px solid rgba(255, 255, 255, 0.03);

    & > div {
        ${tw`flex items-center mx-auto px-4` };
        max-width: 1200px;
        height: 3rem;

        & > a,
        & > div {
            ${tw`inline-flex items-center h-full px-5 no-underline transition-all duration-300 relative` };
            ${tw`text-[10px] font-black uppercase tracking-[0.15em] text-neutral-500 whitespace-nowrap` };

            &:hover {
                ${tw`text-cyan-400 bg-cyan-500/5` };
            }

            &:active,
            &.active {
                ${tw`text-cyan-300 bg-cyan-500/10` };
                
                /* Neon Active Indicator */
                &::after {
                    content: '';
                    ${tw`absolute bottom-0 left-0 right-0 h-[2px] bg-cyan-500` };
                    box-shadow: 0 0 12px rgba(6, 182, 212, 0.8);
                }
            }

            /* Subtle separator between items */
            &:not(:last-of-type)::before {
                content: "/";
                ${tw`absolute -right-1 text-[8px] text-neutral-800 font-mono pointer-events-none` };
            }
        }
    }

    /* Custom scrollbar for the overflow-x-auto HUD feel */
    &::-webkit-scrollbar {
        height: 2px;
    }
    &::-webkit-scrollbar-thumb {
        ${tw`bg-cyan-500/20 rounded-full` };
    }
`;

export default SubNavigation;