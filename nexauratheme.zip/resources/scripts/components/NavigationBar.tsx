import * as React from 'react';
import { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCogs, faLayerGroup, faSignOutAlt } from '@fortawesome/free-solid-svg-icons';
import { useStoreState } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import SearchContainer from '@/components/dashboard/search/SearchContainer';
import tw from 'twin.macro';
import styled from 'styled-components/macro';
import http from '@/api/http';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import Tooltip from '@/components/elements/tooltip/Tooltip';
import Avatar from '@/components/Avatar';

const NavigationContainer = styled.div`
    ${tw`w-full sticky top-0 z-50 transition-all duration-500` };
    background: rgba(10, 10, 10, 0.7);
    backdrop-filter: blur(12px);
    border-bottom: 1px solid rgba(6, 182, 212, 0.1);
`;

const NavItem = styled.div`
    ${tw`h-full flex items-center justify-center` };
    
    & > a, & > button {
        ${tw`flex items-center justify-center h-full px-5 text-neutral-400 transition-all duration-300 relative` };

        &:hover {
            ${tw`text-cyan-400 bg-cyan-500/5` };
        }

        &.active {
            ${tw`text-cyan-400` };
            &::after {
                content: '';
                ${tw`absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-500 shadow-[0_0_10px_rgba(6,182,212,0.8)]` };
            }
        }
    }
`;

const LogoText = styled(Link)`
    ${tw`text-xl font-black uppercase tracking-[0.2em] px-6 no-underline text-white transition-all duration-300` };
    text-shadow: 0 0 15px rgba(255, 255, 255, 0.2);
    
    span {
        ${tw`text-cyan-500` };
    }

    &:hover {
        ${tw`text-cyan-400` };
        text-shadow: 0 0 20px rgba(6, 182, 212, 0.4);
    }
`;

export default () => {
    const name = useStoreState((state: ApplicationStore) => state.settings.data!.name);
    const rootAdmin = useStoreState((state: ApplicationStore) => state.user.data!.rootAdmin);
    const [isLoggingOut, setIsLoggingOut] = useState(false);

    const onTriggerLogout = () => {
        setIsLoggingOut(true);
        http.post('/auth/logout').finally(() => {
            // @ts-expect-error this is valid
            window.location = '/';
        });
    };

    return (
        <NavigationContainer>
            <SpinnerOverlay visible={isLoggingOut} />
            <div className={'mx-auto w-full flex items-center h-[4rem] max-w-[1200px]'}>
                <div id={'logo'} className={'flex-1'}>
                    <LogoText to={'/'}>
                        {name}<span>_</span>OS
                    </LogoText>
                </div>

                <div className={'flex h-full items-center'}>
                    <SearchContainer />
                    
                    <NavItem>
                        <Tooltip placement={'bottom'} content={'Dashboard'}>
                            <NavLink to={'/'} exact>
                                <FontAwesomeIcon icon={faLayerGroup} />
                            </NavLink>
                        </Tooltip>

                        {rootAdmin && (
                            <Tooltip placement={'bottom'} content={'Admin Terminal'}>
                                <a href={'/admin'} rel={'noreferrer'}>
                                    <FontAwesomeIcon icon={faCogs} />
                                </a>
                            </Tooltip>
                        )}

                        <Tooltip placement={'bottom'} content={'User Profile'}>
                            <NavLink to={'/account'}>
                                <div css={tw`w-6 h-6 rounded-lg border border-white/10 overflow-hidden bg-white/5 p-0.5 transition-all group-hover:border-cyan-500/50`}>
                                    <Avatar.User />
                                </div>
                            </NavLink>
                        </Tooltip>

                        <Tooltip placement={'bottom'} content={'Terminate Session'}>
                            <button onClick={onTriggerLogout}>
                                <FontAwesomeIcon icon={faSignOutAlt} />
                            </button>
                        </Tooltip>
                    </NavItem>
                </div>
            </div>
        </NavigationContainer>
    );
};