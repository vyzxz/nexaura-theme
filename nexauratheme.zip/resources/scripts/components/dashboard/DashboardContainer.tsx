import React, { useEffect, useState } from 'react';
import { Server } from '@/api/server/getServer';
import getServers from '@/api/getServers';
import ServerRow from '@/components/dashboard/ServerRow';
import Spinner from '@/components/elements/Spinner';
import PageContentBlock from '@/components/elements/PageContentBlock';
import useFlash from '@/plugins/useFlash';
import { useStoreState } from 'easy-peasy';
import { usePersistedState } from '@/plugins/usePersistedState';
import Switch from '@/components/elements/Switch';
import tw from 'twin.macro';
import useSWR from 'swr';
import { PaginatedResult } from '@/api/http';
import Pagination from '@/components/elements/Pagination';
import { useLocation } from 'react-router-dom';
import styled from 'styled-components/macro';

const DashboardHeader = styled.div`
    ${tw`flex flex-col sm:flex-row items-center justify-between mb-10 p-6 bg-neutral-900/40 border border-white/5 backdrop-blur-lg rounded-2xl shadow-xl`};
`;

export default () => {
    const { search } = useLocation();
    const defaultPage = Number(new URLSearchParams(search).get('page') || '1');

    const [page, setPage] = useState(!isNaN(defaultPage) && defaultPage > 0 ? defaultPage : 1);
    const { clearFlashes, clearAndAddHttpError } = useFlash();
    const uuid = useStoreState((state) => state.user.data!.uuid);
    const rootAdmin = useStoreState((state) => state.user.data!.rootAdmin);
    const [showOnlyAdmin, setShowOnlyAdmin] = usePersistedState(`${uuid}:show_all_servers`, false);

    const { data: servers, error } = useSWR<PaginatedResult<Server>>(
        ['/api/client/servers', showOnlyAdmin && rootAdmin, page],
        () => getServers({ page, type: showOnlyAdmin && rootAdmin ? 'admin' : undefined })
    );

    useEffect(() => {
        setPage(1);
    }, [showOnlyAdmin]);

    useEffect(() => {
        if (!servers) return;
        if (servers.pagination.currentPage > 1 && !servers.items.length) {
            setPage(1);
        }
    }, [servers?.pagination.currentPage]);

    useEffect(() => {
        window.history.replaceState(null, document.title, `/${page <= 1 ? '' : `?page=${page}`}`);
    }, [page]);

    useEffect(() => {
        if (error) clearAndAddHttpError({ key: 'dashboard', error });
        if (!error) clearFlashes('dashboard');
    }, [error]);

    return (
        <PageContentBlock title={'Dashboard'} showFlashKey={'dashboard'}>
            <DashboardHeader>
                <div css={tw`mb-4 sm:mb-0`}>
                    <h1 css={tw`text-2xl font-black text-white tracking-tight`}>Your Servers</h1>
                    <p css={tw`text-xs text-neutral-500 uppercase tracking-widest font-bold mt-1`}>
                        {servers ? `${servers.pagination.total} Total Instances` : 'Loading instance data...'}
                    </p>
                </div>

                {rootAdmin && (
                    <div css={tw`flex items-center bg-black/20 py-2 px-4 rounded-xl border border-white/5`}>
                        <p css={tw`uppercase text-[10px] font-black tracking-[0.2em] text-neutral-400 mr-4`}>
                            {showOnlyAdmin ? "Showing others' servers" : 'Showing your servers'}
                        </p>
                        <Switch
                            name={'show_all_servers'}
                            defaultChecked={showOnlyAdmin}
                            onChange={() => setShowOnlyAdmin((s) => !s)}
                        />
                    </div>
                )}
            </DashboardHeader>

            {!servers ? (
                <div css={tw`py-20`}>
                    <Spinner centered size={'large'} />
                </div>
            ) : (
                <div css={tw`space-y-3`}>
                    <Pagination data={servers} onPageSelect={setPage}>
                        {({ items }) =>
                            items.length > 0 ? (
                                items.map((server) => (
                                    <div key={server.uuid} css={tw`transition-all duration-300 hover:translate-x-1`}>
                                        <ServerRow server={server} />
                                    </div>
                                ))
                            ) : (
                                <div css={tw`bg-neutral-900/40 border border-dashed border-neutral-800 rounded-2xl py-20 text-center`}>
                                    <p css={tw`text-sm text-neutral-400 italic`}>
                                        {showOnlyAdmin
                                            ? 'There are no other servers to display.'
                                            : 'There are no servers associated with your account.'}
                                    </p>
                                </div>
                            )
                        }
                    </Pagination>
                </div>
            )}

            {/* Premium Nexaura Branding Footer */}
            <div css={tw`mt-20 py-10 border-t border-white/5 flex flex-col items-center justify-center opacity-50`}>
                <div css={tw`flex items-center space-x-3 mb-2`}>
                    <div css={tw`h-px w-8 bg-neutral-800`} />
                    <p css={tw`text-[10px] text-neutral-500 uppercase tracking-[0.4em] font-black`}>
                        Powered by <span css={tw`text-cyan-500`}>Nexaura</span>
                    </p>
                    <div css={tw`h-px w-8 bg-neutral-800`} />
                </div>
                <p css={tw`text-[9px] text-neutral-600 uppercase tracking-widest`}>
                    Refining the Pterodactyl Experience
                </p>
            </div>
        </PageContentBlock>
    );
};