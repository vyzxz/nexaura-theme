import React, { useEffect, useState } from 'react';
import { ActivityLogFilters, useActivityLogs } from '@/api/account/activity';
import { useFlashKey } from '@/plugins/useFlash';
import PageContentBlock from '@/components/elements/PageContentBlock';
import FlashMessageRender from '@/components/FlashMessageRender';
import { Link } from 'react-router-dom';
import PaginationFooter from '@/components/elements/table/PaginationFooter';
import { DesktopComputerIcon, XCircleIcon, ShieldCheckIcon } from '@heroicons/react/solid';
import Spinner from '@/components/elements/Spinner';
import ActivityLogEntry from '@/components/elements/activity/ActivityLogEntry';
import Tooltip from '@/components/elements/tooltip/Tooltip';
import useLocationHash from '@/plugins/useLocationHash';
import tw from 'twin.macro';
import styled from 'styled-components/macro';

// --- Styled HUD Elements ---
const LogContainer = styled.div`
    ${tw`rounded-xl overflow-hidden border border-white/5 bg-white/[0.02]! backdrop-blur-xl transition-all duration-500` };
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
`;

const HeaderStatus = styled.div`
    ${tw`flex items-center px-6 py-4 bg-white/[0.03] border-b border-white/5` };
`;

const ClearFilterBtn = styled(Link)`
    ${tw`flex items-center text-[10px] uppercase tracking-widest font-black px-4 py-2 rounded-lg transition-all duration-300` };
    ${tw`bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500/20 hover:border-red-500/40` };
`;

export default () => {
    const { hash } = useLocationHash();
    const { clearAndAddHttpError } = useFlashKey('account');
    const [filters, setFilters] = useState<ActivityLogFilters>({ page: 1, sorts: { timestamp: -1 } });
    const { data, isValidating, error } = useActivityLogs(filters, {
        revalidateOnMount: true,
        revalidateOnFocus: false,
    });

    useEffect(() => {
        setFilters((value) => ({ ...value, filters: { ip: hash.ip, event: hash.event } }));
    }, [hash]);

    useEffect(() => {
        clearAndAddHttpError(error);
    }, [error]);

    return (
        <PageContentBlock title={'Account Activity Log'}>
            {/* Sector Header */}
            <div css={tw`flex items-center justify-between mb-8`}>
                <div css={tw`flex items-center`}>
                    <div css={tw`p-3 bg-cyan-500/10 rounded-xl border border-cyan-500/20 mr-4`}>
                        <ShieldCheckIcon css={tw`w-6 h-6 text-cyan-400`} />
                    </div>
                    <div>
                        <div css={tw`inline-flex items-center px-2 py-0.5 rounded bg-cyan-500/10 border border-cyan-500/20 mb-1`}>
                            <span css={tw`text-[8px] font-black uppercase tracking-[0.2em] text-cyan-400`}>System_Audit</span>
                        </div>
                        <h1 css={tw`text-3xl font-black uppercase tracking-tighter text-white`}>
                            Activity <span css={tw`text-cyan-500`}>Telemetry</span>
                        </h1>
                    </div>
                </div>

                {(filters.filters?.event || filters.filters?.ip) && (
                    <ClearFilterBtn
                        to={'#'}
                        onClick={() => setFilters((value) => ({ ...value, filters: {} }))}
                    >
                        Reset_Telemetry <XCircleIcon css={tw`w-4 h-4 ml-2`} />
                    </ClearFilterBtn>
                )}
            </div>

            <FlashMessageRender byKey={'account'} />

            {!data && isValidating ? (
                <div css={tw`py-20`}>
                    <Spinner centered />
                    <p css={tw`text-center text-[10px] uppercase tracking-[0.3em] text-cyan-500/40 mt-4 animate-pulse`}>
                        Fetching_Historical_Data...
                    </p>
                </div>
            ) : (
                <LogContainer>
                    <HeaderStatus>
                        <div css={tw`w-2 h-2 rounded-full bg-cyan-500 shadow-[0_0_8px_rgba(6,182,212,0.6)] mr-3 animate-pulse`} />
                        <span css={tw`text-[10px] font-black uppercase tracking-widest text-neutral-400`}>
                            Live_Feed // {data?.pagination.total || 0} Events_Logged
                        </span>
                    </HeaderStatus>

                    <div css={tw`divide-y divide-white/5`}>
                        {data?.items.map((activity) => (
                            <ActivityLogEntry 
                                key={activity.id} 
                                activity={activity}
                                // Note: ActivityLogEntry styling is likely handled in its own component, 
                                // but the container wrap ensures the Sector-07 layout holds.
                            >
                                {typeof activity.properties.useragent === 'string' && (
                                    <Tooltip content={activity.properties.useragent} placement={'top'}>
                                        <div css={tw`p-2 rounded-lg bg-white/5 border border-white/5 text-neutral-400 hover:text-cyan-400 transition-colors`}>
                                            <DesktopComputerIcon css={tw`w-4 h-4`} />
                                        </div>
                                    </Tooltip>
                                )}
                            </ActivityLogEntry>
                        ))}
                    </div>

                    {data?.items.length === 0 && (
                        <div css={tw`py-16 text-center`}>
                            <p css={tw`text-sm font-mono text-neutral-600 uppercase tracking-[0.2em]`}>
                                No_Audit_Records_Found
                            </p>
                        </div>
                    )}
                </LogContainer>
            )}

            {data && (
                <div css={tw`mt-6`}>
                    <PaginationFooter
                        pagination={data.pagination}
                        onPageSelect={(page) => setFilters((value) => ({ ...value, page }))}
                    />
                </div>
            )}
        </PageContentBlock>
    );
};