import React, { useContext } from 'react';
import tw from 'twin.macro';
import Button from '@/components/elements/Button';
import asModal from '@/hoc/asModal';
import ModalContext from '@/context/ModalContext';
import CopyOnClick from '@/components/elements/CopyOnClick';
import styled, { css } from 'styled-components/macro';

interface Props {
    apiKey: string;
}

const KeyContainer = styled.pre`
    ${tw`relative overflow-hidden text-sm bg-black/60 border border-cyan-500/30 rounded-xl py-4 px-6 font-mono transition-all duration-300`};
    /* Standard CSS for shadows to avoid Tailwind version errors */
    box-shadow: inset 0 0 20px rgba(6, 182, 212, 0.05), 0 0 15px rgba(6, 182, 212, 0.1);

    &:hover {
        ${tw`border-cyan-500/60`};
        box-shadow: inset 0 0 25px rgba(6, 182, 212, 0.1), 0 0 20px rgba(6, 182, 212, 0.2);
    }
`;

const ApiKeyModal = ({ apiKey }: Props) => {
    const { dismiss } = useContext(ModalContext);

    return (
        <div css={tw`p-2`}>
            <div css={tw`flex items-center mb-6`}>
                {/* Manual CSS for the glowing dot */}
                <div 
                    css={[
                        tw`h-2 w-2 bg-cyan-500 rounded-full mr-3 animate-pulse`,
                        css`box-shadow: 0 0 8px #06b6d4;`
                    ]} 
                />
                <h3 css={tw`text-2xl font-black uppercase tracking-tighter text-white`}>
                    Access Token Generated
                </h3>
            </div>

            <div css={tw`bg-red-500/10 border-l-4 border-red-500 p-4 mb-8 rounded-r-lg`}>
                <p css={tw`text-xs font-bold uppercase tracking-widest text-red-400 mb-1`}>
                    Security Warning
                </p>
                <p css={tw`text-sm text-neutral-300 leading-relaxed`}>
                    This key grants full access to your account. Store it in a secure password manager immediately. 
                    <span css={tw`text-white font-bold ml-1 italic`}>It will never be shown again.</span>
                </p>
            </div>

            <KeyContainer>
                <CopyOnClick text={apiKey}>
                    {/* Fixed: Moved group to className */}
                    <div className="group" css={tw`flex items-center justify-between cursor-pointer`}>
                        <code 
                            css={[
                                tw`font-mono text-cyan-400 break-all pr-4`,
                                css`&::selection { background: #06b6d4; color: #000; }`
                            ]}
                        >
                            {apiKey}
                        </code>
                        {/* Fixed: flex-shrink-0 for older Tailwind support */}
                        <span css={tw`text-[10px] uppercase tracking-widest text-neutral-600 group-hover:text-cyan-500 transition-colors duration-200 flex-shrink-0 font-bold`}>
                            Click to Copy
                        </span>
                    </div>
                </CopyOnClick>
            </KeyContainer>

            <div css={tw`flex justify-end mt-10`}>
                <Button 
                    type={'button'} 
                    onClick={() => dismiss()}
                    /* Fixed: Removed shadow-cyan-500/20 and replaced with manual CSS */
                    css={[
                        tw`shadow-lg hover:shadow-xl`,
                        css`
                            &:hover {
                                box-shadow: 0 0 20px rgba(6, 182, 212, 0.15);
                            }
                        `
                    ]}
                >
                    I have saved the key
                </Button>
            </div>
        </div>
    );
};

ApiKeyModal.displayName = 'ApiKeyModal';

export default asModal<Props>({
    closeOnEscape: false,
    closeOnBackground: false,
})(ApiKeyModal);