import React, { memo, useEffect, useRef, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEthernet, faHdd, faMemory, faMicrochip, faServer } from '@fortawesome/free-solid-svg-icons';
import { Link } from 'react-router-dom';
import { Server } from '@/api/server/getServer';
import getServerResourceUsage, { ServerPowerState, ServerStats } from '@/api/server/getServerResourceUsage';
import { bytesToString, ip, mbToBytes } from '@/lib/formatters';
import tw from 'twin.macro';
import Spinner from '@/components/elements/Spinner';
import styled, { keyframes, css } from 'styled-components/macro';
import isEqual from 'react-fast-compare';

const pulse = keyframes`
    0% { box-shadow: 0 0 0 0 rgba(34, 197, 94, 0.4); }
    70% { box-shadow: 0 0 0 10px rgba(34, 197, 94, 0); }
    100% { box-shadow: 0 0 0 0 rgba(34, 197, 94, 0); }
`;

const breatheRed = keyframes`
    0%, 100% { opacity: 0.5; }
    50% { opacity: 1; }
`;

const isAlarmState = (current: number, limit: number): boolean => limit > 0 && current / (limit * 1024 * 1024) >= 0.9;

const Icon = memo(
    styled(FontAwesomeIcon)<{ $alarm: boolean }>`
        ${(props) => (props.$alarm ? tw`text-red-400` : tw`text-cyan-500`)};
        filter: ${(props) => (props.$alarm ? 'drop-shadow(0 0 5px rgba(248, 113, 113, 0.5))' : 'drop-shadow(0 0 5px rgba(6, 182, 212, 0.5))')};
    `,
    isEqual
);

const IconDescription = styled.p<{ $alarm: boolean }>`
    ${tw`text-sm ml-2 font-mono font-bold`};
    ${(props) => (props.$alarm ? tw`text-red-200` : tw`text-neutral-200`)};
`;

const StatusIndicatorBox = styled.div<{ $status: ServerPowerState | undefined }>`
    ${tw`grid grid-cols-12 gap-4 relative no-underline mb-3` };
    ${tw`bg-neutral-900/40 border border-white/5 backdrop-blur-md rounded-xl p-5 transition-all duration-300` };

    &:hover {
        ${tw`bg-neutral-900/60 border-white/10` };
        transform: translateX(4px);
        box-shadow: 0 10px 30px -10px rgba(0, 0, 0, 0.5);
    }

    & .status-bar {
        ${tw`w-1 absolute left-0 top-0 bottom-0 z-20 rounded-l-xl transition-all duration-150` };
        
        ${({ $status }) =>
            !$status || $status === 'offline'
                ? css`background: #ef4444; box-shadow: 0 0 15px #ef4444; animation: ${breatheRed} 2s infinite;`
                : $status === 'running'
                ? css`background: #22c55e; box-shadow: 0 0 15px #22c55e;`
                : css`background: #eab308; box-shadow: 0 0 15px #eab308;`};
    }
`;

const ServerName = styled.p`
    ${tw`text-lg font-black tracking-tight text-white transition-colors duration-300` };
    ${StatusIndicatorBox}:hover & {
        ${tw`text-cyan-400` };
    }
`;

type Timer = ReturnType<typeof setInterval>;

export default ({ server, className }: { server: Server; className?: string }) => {
    const interval = useRef<Timer>(null) as React.MutableRefObject<Timer>;
    const [isSuspended, setIsSuspended] = useState(server.status === 'suspended');
    const [stats, setStats] = useState<ServerStats | null>(null);

    const getStats = () =>
        getServerResourceUsage(server.uuid)
            .then((data) => setStats(data))
            .catch((error) => console.error(error));

    useEffect(() => {
        setIsSuspended(stats?.isSuspended || server.status === 'suspended');
    }, [stats?.isSuspended, server.status]);

    useEffect(() => {
        if (isSuspended) return;
        getStats().then(() => {
            interval.current = setInterval(() => getStats(), 30000);
        });
        return () => {
            interval.current && clearInterval(interval.current);
        };
    }, [isSuspended]);

    const alarms = { cpu: false, memory: false, disk: false };
    if (stats) {
        alarms.cpu = server.limits.cpu === 0 ? false : stats.cpuUsagePercent >= server.limits.cpu * 0.9;
        alarms.memory = isAlarmState(stats.memoryUsageInBytes, server.limits.memory);
        alarms.disk = server.limits.disk === 0 ? false : isAlarmState(stats.diskUsageInBytes, server.limits.disk);
    }

    const cpuLimit = server.limits.cpu !== 0 ? server.limits.cpu + '%' : '∞';

    return (
        <StatusIndicatorBox as={Link} to={`/server/${server.id}`} className={className} $status={stats?.status}>
            <div className={'status-bar'} />
            
            <div css={tw`flex items-center col-span-12 sm:col-span-5 lg:col-span-6 z-10`}>
                <div css={tw`p-3 rounded-lg bg-black/40 border border-white/5 mr-4 text-cyan-500`}>
                    <FontAwesomeIcon icon={faServer} css={stats?.status === 'running' ? css`animation: ${pulse} 2s infinite;` : ''}/>
                </div>
                <div>
                    <ServerName>{server.name}</ServerName>
                    <p css={tw`text-xs font-mono text-neutral-500 uppercase tracking-widest mt-1`}>
                        {server.allocations.find(a => a.isDefault)?.alias || ip(server.allocations.find(a => a.isDefault)?.ip || '0.0.0.0')}:{server.allocations.find(a => a.isDefault)?.port}
                    </p>
                </div>
            </div>

            <div css={tw`hidden col-span-7 lg:col-span-6 sm:flex items-center justify-end space-x-6 z-10`}>
                {!stats || isSuspended ? (
                    <div css={tw`flex-1 text-right`}>
                        <span css={tw`bg-black/40 border border-white/10 rounded-full px-3 py-1 text-neutral-400 text-[10px] font-bold uppercase tracking-tighter`}>
                            {isSuspended ? 'System Suspended' : 'Initializing HUD...'}
                        </span>
                    </div>
                ) : (
                    <>
                        <div css={tw`flex flex-col items-end`}>
                            <div css={tw`flex items-center`}>
                                <Icon icon={faMicrochip} $alarm={alarms.cpu} />
                                <IconDescription $alarm={alarms.cpu}>{stats.cpuUsagePercent.toFixed(0)}%</IconDescription>
                            </div>
                            <p css={tw`text-[10px] text-neutral-600 uppercase font-black tracking-tighter`}>CPU / {cpuLimit}</p>
                        </div>

                        <div css={tw`flex flex-col items-end`}>
                            <div css={tw`flex items-center`}>
                                <Icon icon={faMemory} $alarm={alarms.memory} />
                                <IconDescription $alarm={alarms.memory}>{bytesToString(stats.memoryUsageInBytes)}</IconDescription>
                            </div>
                            <p css={tw`text-[10px] text-neutral-600 uppercase font-black tracking-tighter`}>Memory</p>
                        </div>

                        <div css={tw`flex flex-col items-end`}>
                            <div css={tw`flex items-center`}>
                                <Icon icon={faHdd} $alarm={alarms.disk} />
                                <IconDescription $alarm={alarms.disk}>{bytesToString(stats.diskUsageInBytes)}</IconDescription>
                            </div>
                            <p css={tw`text-[10px] text-neutral-600 uppercase font-black tracking-tighter`}>Storage</p>
                        </div>
                    </>
                )}
            </div>
        </StatusIndicatorBox>
    );
};