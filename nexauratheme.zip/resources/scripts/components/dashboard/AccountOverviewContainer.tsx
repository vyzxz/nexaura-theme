import React, { Suspense } from 'react';
import PageContentBlock from '@/components/elements/PageContentBlock';
import tw from 'twin.macro';
import styled, { css, keyframes, createGlobalStyle } from 'styled-components/macro';
import MessageBox from '@/components/MessageBox';
import { useLocation } from 'react-router-dom';
import { faUserShield, faMicrochip, faEnvelopeOpenText, faKey } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

// Lazy-loaded forms for performance
const UpdatePasswordForm = React.lazy(() => import('@/components/dashboard/forms/UpdatePasswordForm'));
const UpdateEmailAddressForm = React.lazy(() => import('@/components/dashboard/forms/UpdateEmailAddressForm'));
const ConfigureTwoFactorForm = React.lazy(() => import('@/components/dashboard/forms/ConfigureTwoFactorForm'));

// --- Animations ---
const flicker = keyframes`
    0%, 100% { opacity: 1; filter: drop-shadow(0 0 5px rgba(6, 182, 212, 0.4)); }
    50% { opacity: 0.6; filter: drop-shadow(0 0 2px rgba(6, 182, 212, 0.1)); }
`;

const scanline = keyframes`
    0% { transform: translateY(-100%); }
    100% { transform: translateY(100%); }
`;

// --- Global Theme Overrides ---
// This forces the lazy-loaded Pterodactyl forms to match your HUD aesthetic
const HUDGlobalOverrides = createGlobalStyle`
    .bg-neutral-700, .bg-neutral-800, .bg-neutral-900 {
        background-color: transparent !important;
    }

    label {
        ${tw`text-[9px] uppercase tracking-[0.2em] text-cyan-500/60 font-black mb-2 block` };
    }

    input {
        ${tw`bg-white/5! border-white/10! focus:border-cyan-500/40! transition-all duration-300 rounded-lg! py-3! text-sm font-mono text-white` };
        &:focus { background: rgba(255, 255, 255, 0.08) !important; }
    }

    /* Style the internal Pterodactyl buttons to look like HUDButtons */
    button[type="submit"] {
        ${tw`relative px-8 py-3 font-black uppercase tracking-[0.3em] text-[11px] transition-all duration-500 w-full md:w-auto` };
        background: rgba(6, 182, 212, 0.1) !important;
        border: 1px solid rgba(6, 182, 212, 0.3) !important;
        color: #67e8f9 !important;
        clip-path: polygon(10% 0, 100% 0, 100% 70%, 90% 100%, 0 100%, 0 30%);
        
        &:hover:not(:disabled) {
            background: rgba(6, 182, 212, 0.2) !important;
            border-color: #06b6d4 !important;
            box-shadow: 0 0 20px rgba(6, 182, 212, 0.2) !important;
            transform: translateY(-2px);
        }
    }
`;

// --- Styled Components ---
const TerminalGrid = styled.div`
    ${tw`grid grid-cols-1 lg:grid-cols-3 gap-8 relative` };
`;

const HUDContentBox = styled.div<{ warning?: boolean }>`
    ${tw`p-8 rounded-2xl border transition-all duration-700 relative overflow-hidden h-full flex flex-col` };
    background: ${props => props.warning ? 'rgba(239, 68, 68, 0.02)' : 'rgba(255, 255, 255, 0.02)'};
    backdrop-filter: blur(12px);
    border-color: ${props => props.warning ? 'rgba(239, 68, 68, 0.2)' : 'rgba(6, 182, 212, 0.1)'};

    &::before {
        content: "";
        ${tw`absolute top-0 left-0 w-full h-[1px]` };
        background: linear-gradient(90deg, transparent, ${props => props.warning ? '#ef4444' : '#06b6d4'}, transparent);
        animation: ${flicker} 3s infinite;
    }

    /* Moving Scanline effect */
    &::after {
        content: "";
        ${tw`absolute inset-0 pointer-events-none opacity-[0.02]` };
        background: linear-gradient(to bottom, transparent, #06b6d4, transparent);
        height: 10%;
        animation: ${scanline} 6s linear infinite;
    }

    &:hover {
        background: ${props => props.warning ? 'rgba(239, 68, 68, 0.05)' : 'rgba(6, 182, 212, 0.03)'};
        border-color: ${props => props.warning ? 'rgba(239, 68, 68, 0.4)' : 'rgba(6, 182, 212, 0.4)'};
    }
`;

const HUDTitle = styled.h2`
    ${tw`text-xl font-black text-white uppercase tracking-tighter mb-1` };
`;

const HUDSubheader = styled.div`
    ${tw`flex items-center gap-2 mb-8` };
    & p { ${tw`text-[10px] text-neutral-500 uppercase font-black tracking-widest leading-none` }; }
`;

const HeaderBadge = styled.div`
    ${tw`inline-flex items-center px-3 py-1 rounded-full border border-cyan-500/30 bg-cyan-500/5 mb-4` };
    & span { ${tw`text-[9px] font-black uppercase tracking-[0.2em] text-cyan-400` }; }
`;

const HUDLoader = () => (
    <div css={tw`py-10 flex flex-col items-center justify-center gap-3`}>
        <div css={tw`w-4 h-4 border-2 border-cyan-500/20 border-t-cyan-500 rounded-full animate-spin`} />
        <p css={tw`text-[9px] font-mono text-cyan-500/40 animate-pulse uppercase tracking-[0.4em]`}>
            Decrypting_Module...
        </p>
    </div>
);

export default () => {
    const { state } = useLocation<undefined | { twoFactorRedirect?: boolean }>();

    return (
        <PageContentBlock title={'Account Security'}>
            <HUDGlobalOverrides />
            
            {/* Header Section */}
            <div css={tw`flex items-start mb-12`}>
                <div css={[
                    tw`p-4 bg-cyan-500/10 rounded-2xl border border-cyan-500/20 mr-6`,
                    css`box-shadow: 0 0 30px rgba(6, 182, 212, 0.15);`
                ]}>
                    <FontAwesomeIcon icon={faUserShield} css={tw`text-cyan-400 text-3xl`} />
                </div>
                <div>
                    <HeaderBadge><span>Sector_07 // Auth_Terminal</span></HeaderBadge>
                    <h1 css={tw`text-4xl font-black uppercase tracking-tighter text-white leading-none`}>
                        Security <span css={tw`text-cyan-500`}>Hub</span>
                    </h1>
                    <p css={tw`text-[10px] font-mono text-neutral-500 uppercase tracking-[0.4em] font-bold mt-2`}>
                        Identity Protocols & Access Control
                    </p>
                </div>
            </div>

            {/* Error/Redirect Notice */}
            {state?.twoFactorRedirect && (
                <div css={tw`mb-8 rounded-xl border border-red-500/40 bg-red-500/5 p-2 backdrop-blur-md animate-pulse`}>
                    <MessageBox title={'ENFORCEMENT_NOTICE'} type={'error'}>
                        Access Denied. Security Layer 2 (2FA) must be initialized before proceeding into protected sectors.
                    </MessageBox>
                </div>
            )}

            <TerminalGrid>
                {/* 1. MASTER KEY */}
                <HUDContentBox>
                    <HUDTitle>Master Key</HUDTitle>
                    <HUDSubheader>
                        <FontAwesomeIcon icon={faKey} css={tw`text-cyan-500/40 text-[10px]`} />
                        <p>Credentials_Update</p>
                    </HUDSubheader>
                    <Suspense fallback={<HUDLoader />}>
                        <UpdatePasswordForm />
                    </Suspense>
                </HUDContentBox>

                {/* 2. COMMS UPLINK */}
                <HUDContentBox>
                    <HUDTitle>Comms Uplink</HUDTitle>
                    <HUDSubheader>
                        <FontAwesomeIcon icon={faEnvelopeOpenText} css={tw`text-cyan-500/40 text-[10px]`} />
                        <p>Identity_Channel</p>
                    </HUDSubheader>
                    <Suspense fallback={<HUDLoader />}>
                        <UpdateEmailAddressForm />
                    </Suspense>
                </HUDContentBox>

                {/* 3. IDENTITY LOCK */}
                <HUDContentBox warning>
                    <div css={tw`flex justify-between items-start`}>
                        <div>
                            <HUDTitle>Identity Lock</HUDTitle>
                            <HUDSubheader>
                                <FontAwesomeIcon icon={faMicrochip} css={tw`text-red-500/40 text-[10px]`} />
                                <p>Layer_2_BioLink</p>
                            </HUDSubheader>
                        </div>
                        <div css={[
                            tw`h-1.5 w-8 rounded-full animate-pulse`,
                            css`background: #ef4444; box-shadow: 0 0 15px #ef4444;`
                        ]} />
                    </div>
                    <Suspense fallback={<HUDLoader />}>
                        <ConfigureTwoFactorForm />
                    </Suspense>
                </HUDContentBox>
            </TerminalGrid>
        </PageContentBlock>
    );
};