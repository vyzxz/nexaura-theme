import React, { useEffect, useRef, useState } from 'react';
import Modal, { RequiredModalProps } from '@/components/elements/Modal';
import { Field, Form, Formik, FormikHelpers, useFormikContext } from 'formik';
import { Actions, useStoreActions, useStoreState } from 'easy-peasy';
import { object, string } from 'yup';
import debounce from 'debounce';
import FormikFieldWrapper from '@/components/elements/FormikFieldWrapper';
import InputSpinner from '@/components/elements/InputSpinner';
import getServers from '@/api/getServers';
import { Server } from '@/api/server/getServer';
import { ApplicationStore } from '@/state';
import { Link } from 'react-router-dom';
import styled, { css, keyframes } from 'styled-components/macro';
import tw from 'twin.macro';
import Input from '@/components/elements/Input';
import { ip } from '@/lib/formatters';

type Props = RequiredModalProps;

interface Values {
    term: string;
}

const glowPulse = keyframes`
    0%, 100% { box-shadow: 0 0 5px rgba(6, 182, 212, 0.1); }
    50% { box-shadow: 0 0 15px rgba(6, 182, 212, 0.3); }
`;

const resultSlide = keyframes`
    from { opacity: 0; transform: translateX(-10px); filter: blur(4px); }
    to { opacity: 1; transform: translateX(0); filter: blur(0); }
`;

const ServerResult = styled(Link)`
    ${tw`flex items-center p-4 rounded-xl border border-white/5 no-underline transition-all duration-300 relative overflow-hidden`};
    background: rgba(255, 255, 255, 0.02);
    backdrop-filter: blur(8px);
    animation: ${resultSlide} 0.3s ease forwards;

    &:hover {
        ${tw`border-cyan-500/40`};
        background: rgba(6, 182, 212, 0.08);
        transform: scale(1.01);
        box-shadow: 0 0 30px rgba(6, 182, 212, 0.1);
    }

    &:not(:last-of-type) { ${tw`mb-3` }; }
    
    &::before {
        content: "";
        ${tw`absolute left-0 top-0 bottom-0 w-0.5 bg-cyan-500 opacity-0 transition-opacity duration-300` };
    }

    &:hover::before { ${tw`opacity-100` }; }
`;

const SearchWatcher = () => {
    const { values, submitForm } = useFormikContext<Values>();
    useEffect(() => {
        if (values.term.length >= 3) submitForm();
    }, [values.term]);
    return null;
};

export default ({ ...props }: Props) => {
    const ref = useRef<HTMLInputElement>(null);
    const isAdmin = useStoreState((state: ApplicationStore) => state.user.data!.rootAdmin);
    const [servers, setServers] = useState<Server[]>([]);
    const { clearAndAddHttpError, clearFlashes } = useStoreActions(
        (actions: Actions<ApplicationStore>) => actions.flashes
    );

    const search = debounce(({ term }: Values, { setSubmitting }: FormikHelpers<Values>) => {
        clearFlashes('search');
        getServers({ query: term, type: isAdmin ? 'admin-all' : undefined })
            .then((servers) => setServers(servers.items.filter((_, index) => index < 5)))
            .catch((error) => {
                console.error(error);
                clearAndAddHttpError({ key: 'search', error });
            })
            .then(() => setSubmitting(false))
            .then(() => ref.current?.focus());
    }, 500);

    useEffect(() => {
        if (props.visible && ref.current) ref.current.focus();
    }, [props.visible]);

    return (
        <Formik
            onSubmit={search}
            validationSchema={object().shape({
                term: string().min(3, 'Query minimum: 3 chars.'),
            })}
            initialValues={{ term: '' } as Values}
        >
            {({ isSubmitting }) => (
                <Modal {...props}>
                    <Form>
                        <div css={tw`flex items-center justify-between mb-2`}>
                            <p css={tw`text-[10px] uppercase tracking-[0.4em] text-cyan-400 font-black`}>System_Query</p>
                            <span css={tw`text-[8px] font-mono text-neutral-600`}>STATUS: LISTENING</span>
                        </div>
                        
                        <FormikFieldWrapper name={'term'} label={''} description={'Enter node name, uuid, or network identifier...'}>
                            <SearchWatcher />
                            <InputSpinner visible={isSubmitting}>
                                <Field 
                                    as={Input} 
                                    name={'term'} 
                                    placeholder="TYPE_TO_SCAN..." 
                                    ref={ref}
                                    css={[
                                        tw`bg-white/5! border-white/10! focus:border-cyan-500/50! font-mono text-sm text-white py-4 transition-all duration-300`,
                                        css`&:focus { background: rgba(6, 182, 212, 0.03) !important; animation: ${glowPulse} 2s infinite; }`
                                    ]}
                                />
                            </InputSpinner>
                        </FormikFieldWrapper>
                    </Form>
                    
                    {servers.length > 0 && (
                        <div css={tw`mt-8 pt-6 border-t border-white/5`}>
                            <div css={tw`flex items-center mb-4`}>
                                <div css={tw`w-1 h-1 bg-cyan-500 mr-2 shadow-[0_0_5px_rgba(6,182,212,1)]`} />
                                <p css={tw`text-[9px] uppercase tracking-widest text-neutral-400 font-black`}>
                                    Matched_Nodes // {servers.length} Detected
                                </p>
                            </div>
                            
                            {servers.map((server, index) => (
                                <ServerResult
                                    key={server.uuid}
                                    to={`/server/${server.id}`}
                                    onClick={() => props.onDismissed()}
                                    style={{ animationDelay: `${index * 50}ms` }}
                                >
                                    <div css={tw`flex-1 mr-4`}>
                                        <div css={tw`flex items-center gap-2`}>
                                            <p css={tw`text-sm font-black text-white uppercase tracking-tight`}>{server.name}</p>
                                            <div css={tw`w-1 h-1 rounded-full bg-cyan-500/40`} />
                                            <span css={tw`text-[9px] font-mono text-neutral-500 uppercase`}>{server.uuid.split('-')[0]}</span>
                                        </div>
                                        <p css={tw`mt-1 text-[10px] font-mono text-cyan-400/50 tracking-tighter`}>
                                            {server.allocations
                                                .filter((alloc) => alloc.isDefault)
                                                .map((allocation) => (
                                                    <span key={`${allocation.ip}-${allocation.port}`}>
                                                        {allocation.alias || ip(allocation.ip)}:{allocation.port}
                                                    </span >
                                                ))}
                                        </p>
                                    </div>
                                    <div css={tw`flex-none text-right`}>
                                        <div css={tw`text-[8px] text-neutral-600 font-black uppercase mb-1`}>Assigned_Node</div>
                                        <span css={tw`text-[9px] font-black py-1 px-3 rounded bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 uppercase tracking-tighter`}>
                                            {server.node}
                                        </span>
                                    </div>
                                </ServerResult>
                            ))}
                        </div>
                    )}
                </Modal>
            )}
        </Formik>
    );
};