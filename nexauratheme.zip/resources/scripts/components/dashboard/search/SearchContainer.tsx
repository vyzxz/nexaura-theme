import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch } from '@fortawesome/free-solid-svg-icons';
import useEventListener from '@/plugins/useEventListener';
import SearchModal from '@/components/dashboard/search/SearchModal';
import Tooltip from '@/components/elements/tooltip/Tooltip';
import styled, { keyframes } from 'styled-components/macro';
import tw from 'twin.macro';

const pulse = keyframes`
    0% { transform: scale(1); opacity: 0.5; }
    50% { transform: scale(1.4); opacity: 0; }
    100% { transform: scale(1); opacity: 0; }
`;

const SearchTrigger = styled.div`
    ${tw`relative flex items-center justify-center w-9 h-9 rounded-lg cursor-pointer transition-all duration-300` };
    background: rgba(255, 255, 255, 0.03);
    border: 1px solid rgba(255, 255, 255, 0.05);

    & svg {
        ${tw`text-neutral-500 transition-colors duration-300 text-sm` };
    }

    &:hover {
        ${tw`border-cyan-500/40` };
        background: rgba(6, 182, 212, 0.1);
        
        & svg {
            ${tw`text-cyan-400` };
            filter: drop-shadow(0 0 8px rgba(6, 182, 212, 0.5));
        }

        &::after {
            content: "";
            ${tw`absolute inset-0 rounded-lg border border-cyan-500/50` };
            animation: ${pulse} 2s infinite;
        }
    }
`;

const Label = styled.span`
    ${tw`mr-3 text-[9px] font-black uppercase tracking-[0.2em] text-neutral-500 hidden xl:block` };
    span { ${tw`text-cyan-500/40` } }
`;

const ShortcutHint = styled.span`
    ${tw`ml-3 text-[9px] text-neutral-600 font-mono hidden lg:inline-block uppercase tracking-tighter` };
`;

export default () => {
    const [visible, setVisible] = useState(false);

    useEventListener('keydown', (e: KeyboardEvent) => {
        if (['input', 'textarea'].indexOf(((e.target as HTMLElement).tagName || 'input').toLowerCase()) < 0) {
            // Support both Cmd+/ and just / for quick terminal feel
            if (!visible && (e.metaKey || e.ctrlKey || e.key === '/') && e.key.toLowerCase() === '/') {
                setVisible(true);
            }
        }
    });

    return (
        <>
            {visible && <SearchModal appear visible={visible} onDismissed={() => setVisible(false)} />}
            <div css={tw`flex items-center px-4 border-r border-white/5 h-full mr-2`}>
                <Label>Search<span>_</span>Probe</Label>
                <Tooltip placement={'bottom'} content={'Initialize Global Search'}>
                    <div css={tw`flex items-center`}>
                        <SearchTrigger onClick={() => setVisible(true)}>
                            <FontAwesomeIcon icon={faSearch} />
                        </SearchTrigger>
                        <ShortcutHint>[CMD + /]</ShortcutHint>
                    </div>
                </Tooltip>
            </div>
        </>
    );
};