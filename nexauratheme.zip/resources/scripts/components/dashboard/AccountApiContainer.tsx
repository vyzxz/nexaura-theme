import React, { useEffect, useState } from 'react';
import ContentBox from '@/components/elements/ContentBox';
import CreateApiKeyForm from '@/components/dashboard/forms/CreateApiKeyForm';
import getApiKeys, { ApiKey } from '@/api/account/getApiKeys';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faKey, faTrashAlt, faTerminal } from '@fortawesome/free-solid-svg-icons';
import deleteApiKey from '@/api/account/deleteApiKey';
import FlashMessageRender from '@/components/FlashMessageRender';
import { format } from 'date-fns';
import PageContentBlock from '@/components/elements/PageContentBlock';
import tw from 'twin.macro';
import GreyRowBox from '@/components/elements/GreyRowBox';
import { Dialog } from '@/components/elements/dialog';
import { useFlashKey } from '@/plugins/useFlash';
import Code from '@/components/elements/Code';
import styled, { createGlobalStyle } from 'styled-components/macro';

// --- Global Form Styles ---
const GlobalHUDFormStyle = createGlobalStyle`
    .bg-neutral-700, .bg-neutral-800, .bg-neutral-900 {
        background-color: transparent !important;
    }
    
    label {
        ${tw`text-[9px] uppercase tracking-widest text-cyan-500/60 font-black mb-2 block` };
    }

    input {
        ${tw`bg-white/5! border-white/10! focus:border-cyan-500/40! transition-all duration-300 rounded-lg! py-3! text-sm font-mono text-white` };
        &:focus { background: rgba(255, 255, 255, 0.08) !important; }
    }

    button[type="submit"] {
        ${tw`relative px-10 py-3 rounded-lg font-black uppercase tracking-[0.3em] text-[10px] transition-all duration-500 w-full` };
        background: rgba(6, 182, 212, 0.1) !important;
        border: 1px solid rgba(6, 182, 212, 0.3) !important;
        color: #67e8f9 !important;

        &:hover:not(:disabled) {
            background: rgba(6, 182, 212, 0.2) !important;
            border-color: rgba(6, 182, 212, 0.6) !important;
            box-shadow: 0 0 25px rgba(6, 182, 212, 0.2) !important;
        }
    }
`;

// --- Styled HUD Components ---
const ApiKeyRow = styled(GreyRowBox)`
    ${tw`bg-white/[0.02]! border border-white/5 flex items-center p-4 transition-all duration-300 relative overflow-hidden rounded-xl` };
    backdrop-filter: blur(8px);
    
    &:hover {
        ${tw`border-cyan-500/30 bg-white/[0.05]!` };
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
    }

    &::before {
        content: "";
        ${tw`absolute left-0 top-0 bottom-0 w-1 bg-cyan-500 opacity-0 transition-opacity duration-300` };
    }

    &:hover::before {
        ${tw`opacity-100` };
    }
`;

const IdentifierCode = styled.code`
    ${tw`font-mono py-1 px-3 bg-black/50 border border-white/5 text-cyan-400 rounded-lg text-xs tracking-tighter` };
    text-shadow: 0 0 8px rgba(6, 182, 212, 0.4);
`;

const HUDContentBox = styled(ContentBox)`
    ${tw`bg-white/[0.02]! backdrop-blur-xl border-white/5! relative overflow-hidden transition-all duration-500` };
    & > div { background-color: transparent !important; }
`;

export default () => {
    const [deleteIdentifier, setDeleteIdentifier] = useState('');
    const [keys, setKeys] = useState<ApiKey[]>([]);
    const [loading, setLoading] = useState(true);
    const { clearAndAddHttpError } = useFlashKey('account');

    useEffect(() => {
        getApiKeys()
            .then((keys) => setKeys(keys))
            .then(() => setLoading(false))
            .catch((error) => clearAndAddHttpError(error));
    }, []);

    const doDeletion = (identifier: string) => {
        setLoading(true);
        clearAndAddHttpError();
        deleteApiKey(identifier)
            .then(() => setKeys((s) => [...(s || []).filter((key) => key.identifier !== identifier)]))
            .catch((error) => clearAndAddHttpError(error))
            .then(() => {
                setLoading(false);
                setDeleteIdentifier('');
            });
    };

    return (
        <PageContentBlock title={'Account API'}>
            <GlobalHUDFormStyle />
            
            <div css={tw`flex items-center mb-10`}>
                <div css={tw`p-4 bg-cyan-500/10 rounded-2xl border border-cyan-500/20 mr-5 shadow-[0_0_30px_rgba(6,182,212,0.15)]`}>
                    <FontAwesomeIcon icon={faTerminal} css={tw`text-cyan-400 text-2xl`} />
                </div>
                <div>
                    <div css={tw`inline-flex items-center px-3 py-1 rounded-full border border-cyan-500/30 bg-cyan-500/5 mb-2`}>
                        <span css={tw`text-[9px] font-black uppercase tracking-[0.2em] text-cyan-400`}>Sector_07 // API_Uplink</span>
                    </div>
                    <h1 css={tw`text-4xl font-black uppercase tracking-tighter text-white leading-none`}>
                        Developer <span css={tw`text-cyan-500`}>Credentials</span>
                    </h1>
                </div>
            </div>

            <FlashMessageRender byKey={'account'} />
            
            <div css={tw`md:flex flex-nowrap my-10 gap-8`}>
                <HUDContentBox title={'Create New Key'} css={tw`flex-none w-full md:w-1/3`}>
                    <div css={tw`mb-6`}>
                        <p css={tw`text-[10px] text-neutral-500 uppercase font-bold tracking-widest`}>Protocol_Initialize</p>
                    </div>
                    <CreateApiKeyForm onKeyCreated={(key) => setKeys((s) => [...s!, key])} />
                </HUDContentBox>

                <HUDContentBox title={'Active Tokens'} css={tw`flex-1 overflow-hidden mt-8 md:mt-0`}>
                    <SpinnerOverlay visible={loading} />
                    <Dialog.Confirm
                        title={'Revoke API Key'}
                        confirm={'Confirm Revocation'}
                        open={!!deleteIdentifier}
                        onClose={() => setDeleteIdentifier('')}
                        onConfirmed={() => doDeletion(deleteIdentifier)}
                    >
                        Access for identifier <Code>{deleteIdentifier}</Code> will be permanently terminated.
                    </Dialog.Confirm>

                    {keys.length === 0 ? (
                        <div css={tw`py-12 text-center border border-dashed border-white/5 rounded-xl`}>
                            <p css={tw`text-sm text-neutral-600 font-mono uppercase tracking-widest`}>
                                {loading ? 'Scanning_Sector...' : 'No_Active_Tokens_Detected'}
                            </p>
                        </div>
                    ) : (
                        <div css={tw`space-y-4`}>
                            {keys.map((key) => (
                                <ApiKeyRow key={key.identifier}>
                                    <div css={tw`p-3 bg-cyan-500/10 rounded-lg mr-4 border border-cyan-500/10`}>
                                        <FontAwesomeIcon icon={faKey} css={tw`text-cyan-400`} />
                                    </div>
                                    <div css={tw`flex-1 min-w-0`}>
                                        <p css={tw`text-sm font-black text-white uppercase tracking-tight truncate`}>{key.description}</p>
                                        <p css={tw`text-[10px] text-neutral-500 uppercase tracking-widest mt-1 font-bold`}>
                                            Last_Uplink: {key.lastUsedAt ? format(key.lastUsedAt, 'HH:mm // MMM do') : 'NEVER'}
                                        </p>
                                    </div>
                                    <div css={tw`ml-4 hidden xl:block`}>
                                        <IdentifierCode>{key.identifier}</IdentifierCode>
                                    </div>
                                    {/* FIXED: 'group' class moved to className to resolve twin.macro build error */}
                                    <button 
                                        className={'group'}
                                        css={tw`ml-6 p-3 rounded-xl bg-red-500/5 border border-red-500/10 hover:bg-red-500/20 hover:border-red-500/40 transition-all duration-300`} 
                                        onClick={() => setDeleteIdentifier(key.identifier)}
                                    >
                                        <FontAwesomeIcon
                                            icon={faTrashAlt}
                                            css={tw`text-red-500/50 group-hover:text-red-500 text-sm`}
                                        />
                                    </button>
                                </ApiKeyRow>
                            ))}
                        </div>
                    )}
                </HUDContentBox>
            </div>
        </PageContentBlock>
    );
};