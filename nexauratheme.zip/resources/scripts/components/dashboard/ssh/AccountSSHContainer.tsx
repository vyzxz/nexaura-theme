import React, { useEffect } from 'react';
import ContentBox from '@/components/elements/ContentBox';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import FlashMessageRender from '@/components/FlashMessageRender';
import PageContentBlock from '@/components/elements/PageContentBlock';
import tw from 'twin.macro';
import GreyRowBox from '@/components/elements/GreyRowBox';
import { useSSHKeys } from '@/api/account/ssh-keys';
import { useFlashKey } from '@/plugins/useFlash';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faKey, faShieldAlt } from '@fortawesome/free-solid-svg-icons';
import { format } from 'date-fns';
import CreateSSHKeyForm from '@/components/dashboard/ssh/CreateSSHKeyForm';
import DeleteSSHKeyButton from '@/components/dashboard/ssh/DeleteSSHKeyButton';
import styled, { css } from 'styled-components/macro';

const SSHKeyRow = styled.div`
    ${tw`flex items-center p-5 mb-3 transition-all duration-300 relative overflow-hidden rounded-xl border border-white/5` };
    background: rgba(255, 255, 255, 0.02);
    backdrop-filter: blur(4px);
    
    &:hover {
        ${tw`border-cyan-500/40` };
        background: rgba(6, 182, 212, 0.03);
        box-shadow: 0 0 20px rgba(6, 182, 212, 0.05);
        transform: scale(1.01);
    }

    /* Side glow indicator */
    &::before {
        content: "";
        ${tw`absolute left-0 top-0 bottom-0 w-[2px] bg-cyan-500 opacity-0 transition-opacity duration-300` };
        box-shadow: 0 0 10px #06b6d4;
    }

    &:hover::before {
        ${tw`opacity-100` };
    }
`;

const FingerprintCode = styled.p`
    ${tw`text-[10px] mt-1 font-mono text-cyan-400/60 truncate tracking-tighter uppercase` };
    text-shadow: 0 0 8px rgba(6, 182, 212, 0.2);
`;

const HeaderIcon = styled.div`
    ${tw`p-3 rounded-xl border border-cyan-500/30 mr-4 bg-cyan-500/5` };
    box-shadow: 0 0 20px rgba(6, 182, 212, 0.1), inset 0 0 10px rgba(6, 182, 212, 0.1);
`;

export default () => {
    const { clearAndAddHttpError } = useFlashKey('account');
    const { data, isValidating, error } = useSSHKeys({
        revalidateOnMount: true,
        revalidateOnFocus: false,
    });

    useEffect(() => {
        clearAndAddHttpError(error);
    }, [error]);

    return (
        <PageContentBlock title={'SSH Keys'}>
            <div css={tw`flex items-center mb-10`}>
                <HeaderIcon>
                    <FontAwesomeIcon icon={faShieldAlt} css={tw`text-cyan-400 text-2xl`} />
                </HeaderIcon>
                <div>
                    <h1 css={tw`text-3xl font-black uppercase tracking-tighter text-white leading-none`}>
                        Access Nodes
                    </h1>
                    <p css={tw`text-[10px] text-cyan-400/50 uppercase tracking-[0.3em] font-bold mt-1`}>
                        Secure Shell Authentication Protocol
                    </p>
                </div>
            </div>

            <FlashMessageRender byKey={'account'} />
            
            <div css={tw`lg:flex flex-nowrap my-10 gap-12`}>
                {/* Left Side: Create Form */}
                <div css={tw`flex-none w-full lg:w-1/3`}>
                    <CreateSSHKeyForm />
                </div>

                {/* Right Side: Key List */}
                <div css={tw`flex-1 mt-12 lg:mt-0`}>
                    <div css={tw`flex items-center justify-between mb-6 px-2`}>
                        <p css={tw`text-[10px] uppercase tracking-[0.4em] text-neutral-500 font-black`}>
                            02 Active Credentials
                        </p>
                        {isValidating && <span css={tw`text-[9px] text-cyan-500 animate-pulse font-mono`}>REFRESHING_DATABASE...</span>}
                    </div>

                    <SpinnerOverlay visible={!data && isValidating} />
                    
                    {!data || !data.length ? (
                        <div css={tw`py-20 rounded-3xl border border-dashed border-white/5 text-center`}>
                            <p css={tw`text-sm text-neutral-600 font-mono uppercase tracking-widest`}>
                                {!data ? 'Scanning secure storage...' : 'Empty directory: No keys found.'}
                            </p>
                        </div>
                    ) : (
                        <div css={tw`space-y-4`}>
                            {data.map((key) => (
                                <SSHKeyRow key={key.fingerprint}>
                                    <div css={tw`p-3 bg-white/5 rounded-lg mr-5 border border-white/5`}>
                                        <FontAwesomeIcon icon={faKey} css={tw`text-neutral-400`} />
                                    </div>
                                    <div css={tw`flex-1 min-w-0 pr-6`}>
                                        <p css={tw`text-sm font-black text-white tracking-tight uppercase`}>
                                            {key.name}
                                        </p>
                                        <FingerprintCode>FPR :: {key.fingerprint}</FingerprintCode>
                                        <div css={tw`flex items-center mt-2`}>
                                            <span css={tw`w-1 h-1 bg-cyan-500 rounded-full mr-2 shadow-[0_0_5px_#06b6d4]`} />
                                            <p css={tw`text-[9px] text-neutral-500 uppercase tracking-widest font-bold`}>
                                                Verified: {format(key.createdAt, 'MMM dd, yyyy')}
                                            </p>
                                        </div>
                                    </div>
                                    <div css={tw`flex-shrink-0`}>
                                        <DeleteSSHKeyButton name={key.name} fingerprint={key.fingerprint} />
                                    </div>
                                </SSHKeyRow>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </PageContentBlock>
    );
};