import tw from 'twin.macro';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTrashAlt } from '@fortawesome/free-solid-svg-icons';
import React, { useState } from 'react';
import { useFlashKey } from '@/plugins/useFlash';
import { deleteSSHKey, useSSHKeys } from '@/api/account/ssh-keys';
import { Dialog } from '@/components/elements/dialog';
import Code from '@/components/elements/Code';
import styled, { css, keyframes } from 'styled-components/macro';

const scanline = keyframes`
    0% { transform: translateY(-100%); }
    100% { transform: translateY(100%); }
`;

const ActionButton = styled.button`
    ${tw`ml-4 p-2.5 rounded-lg transition-all duration-300 border border-white/5 relative overflow-hidden`};
    background: rgba(239, 68, 68, 0.02);

    &:hover {
        ${tw`border-red-500/40 bg-red-500/10`};
        box-shadow: 0 0 15px rgba(239, 68, 68, 0.1);
        
        & svg {
            ${tw`text-red-500`};
            filter: drop-shadow(0 0 8px rgba(239, 68, 68, 0.6));
        }
    }

    /* Subtle hazard scanline on hover */
    &:hover::after {
        content: "";
        ${tw`absolute inset-0 pointer-events-none opacity-20`};
        background: linear-gradient(to bottom, transparent, #ef4444, transparent);
        animation: ${scanline} 1.5s linear infinite;
    }
`;

const WarningText = styled.div`
    ${tw`mt-4 p-3 rounded-lg border border-red-500/20 bg-red-500/5` };
    
    & p {
        ${tw`text-[10px] text-red-400 italic uppercase font-black tracking-[0.2em] leading-relaxed` };
    }
`;

export default ({ name, fingerprint }: { name: string; fingerprint: string }) => {
    const { clearAndAddHttpError } = useFlashKey('account');
    const [visible, setVisible] = useState(false);
    const { mutate } = useSSHKeys();

    const doDeletion = () => {
        clearAndAddHttpError();
        setVisible(false);

        Promise.all([
            mutate((data) => data?.filter((value) => value.fingerprint !== fingerprint), false),
            deleteSSHKey(fingerprint),
        ]).catch((error) => {
            mutate(undefined, true).catch(console.error);
            clearAndAddHttpError(error);
        });
    };

    return (
        <>
            <Dialog.Confirm
                open={visible}
                title={'Protocol: Revoke Access'}
                confirm={'De-authorize Node'}
                onConfirmed={doDeletion}
                onClose={() => setVisible(false)}
            >
                <div css={tw`space-y-4`}>
                    <p css={tw`text-sm text-neutral-300 font-medium`}>
                        Initiating decommissioning process for node:
                    </p>
                    <div css={tw`bg-black/40 p-4 rounded-xl border border-white/10`}>
                        <Code css={tw`text-cyan-400 bg-transparent! p-0!`}>{name}</Code>
                        <p css={tw`text-[9px] font-mono text-neutral-500 mt-1 uppercase tracking-tighter`}>
                            ID: {fingerprint}
                        </p>
                    </div>
                    <WarningText>
                        <p>
                            CRITICAL: This will immediately invalidate the secure handshake. 
                            Active terminal sessions will be terminated.
                        </p>
                    </WarningText>
                </div>
            </Dialog.Confirm>

            <ActionButton 
                type={'button'} 
                onClick={() => setVisible(true)}
                title={`Revoke ${name}`}
            >
                <FontAwesomeIcon
                    icon={faTrashAlt}
                    css={tw`text-neutral-600 transition-all duration-300`}
                />
            </ActionButton>
        </>
    );
};