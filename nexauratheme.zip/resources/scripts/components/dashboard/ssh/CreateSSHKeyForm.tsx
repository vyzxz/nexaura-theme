import React from 'react';
import { Field, Form, Formik, FormikHelpers } from 'formik';
import { object, string } from 'yup';
import FormikFieldWrapper from '@/components/elements/FormikFieldWrapper';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import tw from 'twin.macro';
import Button from '@/components/elements/Button';
import Input, { Textarea } from '@/components/elements/Input';
import styled, { css, keyframes } from 'styled-components/macro';
import { useFlashKey } from '@/plugins/useFlash';
import { createSSHKey, useSSHKeys } from '@/api/account/ssh-keys';

interface Values {
    name: string;
    publicKey: string;
}

const scanline = keyframes`
    0% { transform: translateY(-100%); }
    100% { transform: translateY(100%); }
`;

/* 1. The Main Container: Deep Navy / Transparent Black */
const GamingCard = styled.div`
    ${tw`p-6 rounded-lg relative overflow-hidden` };
    background: rgba(10, 11, 18, 0.6); /* Matches dark navy backgrounds */
    border: 1px solid rgba(6, 182, 212, 0.2);
    backdrop-filter: blur(10px);
    box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5), inset 0 0 20px rgba(6, 182, 212, 0.05);

    /* The "Scanline" effect for that gaming monitor feel */
    &::after {
        content: "";
        ${tw`absolute inset-0 pointer-events-none opacity-[0.03]` };
        background: linear-gradient(to bottom, transparent, #06b6d4, transparent);
        height: 20%;
        animation: ${scanline} 4s linear infinite;
    }
`;

const InputGroup = styled.div`
    ${tw`relative mb-8` };
    
    & label {
        ${tw`text-[10px] font-black uppercase tracking-[0.25em] text-cyan-400 mb-2 block` };
        text-shadow: 0 0 8px rgba(6, 182, 212, 0.6);
    }
`;

const StyledInput = styled(Input)`
    ${tw`bg-black/40! border-white/5! focus:border-cyan-500/60! text-white! font-mono text-xs transition-all duration-300` };
    border-radius: 4px;
    
    &:focus {
        background: rgba(0, 0, 0, 0.6) !important;
        box-shadow: 0 0 15px rgba(6, 182, 212, 0.15);
    }
`;

const TerminalBox = styled.div<{ hasError?: boolean }>`
    ${tw`rounded border bg-black/50 transition-all duration-300 relative` };
    border-color: ${props => props.hasError ? 'rgba(239, 68, 68, 0.5)' : 'rgba(255, 255, 255, 0.05)'};
    
    &::before {
        content: "TERMINAL_READY";
        ${tw`absolute -top-2 left-3 px-2 bg-[#0a0b12] text-[8px] font-bold text-neutral-500 uppercase tracking-tighter` };
    }

    &:focus-within {
        ${tw`border-cyan-500/40` };
    }
`;

const StyledTextarea = styled(Textarea)`
    ${tw`h-48 font-mono text-[11px] text-cyan-100/90 leading-relaxed bg-transparent! border-none! ring-0! shadow-none! p-4` };
    resize: none;
    &::placeholder { ${tw`text-white/5` }; }
`;

const ActionButton = styled(Button)`
    ${tw`w-full py-4 rounded font-black uppercase tracking-[0.3em] text-[11px] transition-all duration-500` };
    background: linear-gradient(90deg, rgba(6, 182, 212, 0.1) 0%, rgba(6, 182, 212, 0.2) 100%);
    border: 1px solid rgba(6, 182, 212, 0.3);
    color: #22d3ee;
    clip-path: polygon(5% 0, 100% 0, 100% 70%, 95% 100%, 0 100%, 0% 30%); /* Angled "Gaming" corners */

    &:hover:not(:disabled) {
        background: rgba(6, 182, 212, 0.3);
        border-color: #22d3ee;
        color: #fff;
        box-shadow: 0 0 30px rgba(6, 182, 212, 0.3);
        letter-spacing: 0.4em;
    }
    
    &:disabled {
        ${tw`opacity-20 cursor-not-allowed grayscale` };
    }
`;

export default () => {
    const { clearAndAddHttpError } = useFlashKey('account');
    const { mutate } = useSSHKeys();

    const submit = (values: Values, { setSubmitting, resetForm }: FormikHelpers<Values>) => {
        clearAndAddHttpError();
        createSSHKey(values.name, values.publicKey)
            .then((key) => {
                resetForm();
                mutate((data) => (data || []).concat(key));
            })
            .catch((error) => clearAndAddHttpError(error))
            .then(() => setSubmitting(false));
    };

    return (
        <Formik
            onSubmit={submit}
            initialValues={{ name: '', publicKey: '' }}
            validationSchema={object().shape({
                name: string().required().min(3),
                publicKey: string().required(),
            })}
        >
            {({ isSubmitting, errors, touched }) => (
                <GamingCard>
                    <Form>
                        <SpinnerOverlay visible={isSubmitting} />
                        
                        <InputGroup>
                            <label>01 // Node_Identification</label>
                            <FormikFieldWrapper label={''} name={'name'}>
                                <Field 
                                    name={'name'} 
                                    as={StyledInput} 
                                    placeholder={'CMD: SET_IDENTITY...'}
                                />
                            </FormikFieldWrapper>
                        </InputGroup>

                        <InputGroup>
                            <label>02 // Secure_Payload_Buffer</label>
                            <TerminalBox hasError={!!(errors.publicKey && touched.publicKey)}>
                                <Field 
                                    name={'publicKey'} 
                                    as={StyledTextarea} 
                                    placeholder={'WAITING FOR RSA ENCRYPTION INPUT...'}
                                />
                            </TerminalBox>
                        </InputGroup>

                        <div css={tw`mt-10`}>
                            <ActionButton type={'submit'} disabled={isSubmitting}>
                                Establish Secure Link
                            </ActionButton>
                        </div>
                    </Form>
                </GamingCard>
            )}
        </Formik>
    );
};