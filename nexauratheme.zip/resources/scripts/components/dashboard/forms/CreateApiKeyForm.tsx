import React, { useState } from 'react';
import { Field, Form, Formik, FormikHelpers } from 'formik';
import { object, string } from 'yup';
import createApiKey from '@/api/account/createApiKey';
import { Actions, useStoreActions } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import { httpErrorToHuman } from '@/api/http';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import { ApiKey } from '@/api/account/getApiKeys';
import tw from 'twin.macro';
import Input, { Textarea } from '@/components/elements/Input';
import styled from 'styled-components/macro';
import ApiKeyModal from '@/components/dashboard/ApiKeyModal';

interface Values {
    description: string;
    allowedIps: string;
}

// --- Styled Components ---
const CustomTextarea = styled(Textarea)`
    ${tw`h-32 font-mono text-sm! bg-white/[0.03]! border-white/10! focus:border-cyan-500/40! transition-all duration-300 rounded-lg!`}
    resize: none;
`;

const Label = styled.label`
    ${tw`text-[10px] uppercase tracking-[0.2em] text-cyan-500/70 font-black mb-2 block` };
`;

const DescriptionText = styled.p`
    ${tw`text-[10px] text-neutral-500 mt-2 leading-relaxed uppercase tracking-tighter font-bold` };
`;

const HUDButton = styled.button`
    ${tw`relative px-10 py-3 rounded-lg font-black uppercase tracking-[0.3em] text-[10px] transition-all duration-500 w-full md:w-auto` };
    background: rgba(6, 182, 212, 0.1);
    border: 1px solid rgba(6, 182, 212, 0.3);
    color: #67e8f9;

    &:hover:not(:disabled) {
        background: rgba(6, 182, 212, 0.2);
        border-color: rgba(6, 182, 212, 0.6);
        box-shadow: 0 0 25px rgba(6, 182, 212, 0.2);
    }

    &:disabled {
        ${tw`opacity-50 cursor-not-allowed`}
    }
`;

export default ({ onKeyCreated }: { onKeyCreated: (key: ApiKey) => void }) => {
    const [apiKey, setApiKey] = useState('');
    const { addError, clearFlashes } = useStoreActions((actions: Actions<ApplicationStore>) => actions.flashes);

    const submit = (values: Values, { setSubmitting, resetForm }: FormikHelpers<Values>) => {
        clearFlashes('account');
        createApiKey(values.description, values.allowedIps)
            .then(({ secretToken, ...key }) => {
                resetForm();
                setSubmitting(false);
                setApiKey(`${key.identifier}${secretToken}`);
                onKeyCreated(key);
            })
            .catch((error) => {
                console.error(error);
                addError({ key: 'account', message: httpErrorToHuman(error) });
                setSubmitting(false);
            });
    };

    return (
        <>
            <ApiKeyModal visible={apiKey.length > 0} onModalDismissed={() => setApiKey('')} apiKey={apiKey} />
            <Formik
                onSubmit={submit}
                initialValues={{ description: '', allowedIps: '' }}
                validationSchema={object().shape({
                    allowedIps: string(),
                    description: string().required().min(4),
                })}
            >
                {({ isSubmitting, errors, touched }) => (
                    <Form>
                        <SpinnerOverlay visible={isSubmitting} />
                        
                        {/* Description Field */}
                        <div css={tw`mb-8`}>
                            <Label htmlFor={'description'}>Identifier_Key</Label>
                            <Field 
                                id={'description'}
                                name={'description'} 
                                as={Input} 
                                placeholder={'e.g. My Production Bot'}
                                css={[
                                    errors.description && touched.description && tw`border-red-500/50! bg-red-500/5!`
                                ]}
                            />
                            <DescriptionText>Provide a unique designation for this credential.</DescriptionText>
                        </div>

                        {/* IPs Field */}
                        <div css={tw`mb-8`}>
                            <Label htmlFor={'allowedIps'}>Security_Uplink_Filter</Label>
                            <Field 
                                id={'allowedIps'}
                                name={'allowedIps'} 
                                as={CustomTextarea} 
                                placeholder={'0.0.0.0'}
                            />
                            <DescriptionText>
                                Null entry permits all traffic. Otherwise, list authorized IPs per line.
                            </DescriptionText>
                        </div>

                        <div css={tw`flex justify-end`}>
                            <HUDButton type={'submit'} disabled={isSubmitting}>
                                Generate_Credential
                            </HUDButton>
                        </div>
                    </Form>
                )}
            </Formik>
        </>
    );
};