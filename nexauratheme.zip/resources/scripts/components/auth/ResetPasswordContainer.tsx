import React, { useState } from 'react';
import { RouteComponentProps } from 'react-router';
import { Link } from 'react-router-dom';
import performPasswordReset from '@/api/auth/performPasswordReset';
import { httpErrorToHuman } from '@/api/http';
import LoginFormContainer from '@/components/auth/LoginFormContainer';
import { Actions, useStoreActions } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import { Formik, FormikHelpers } from 'formik';
import { object, ref, string } from 'yup';
import Field from '@/components/elements/Field';
import Input from '@/components/elements/Input';
import tw from 'twin.macro';
import Button from '@/components/elements/Button';

interface Values {
    password: string;
    passwordConfirmation: string;
}

export default ({ match, location }: RouteComponentProps<{ token: string }>) => {
    const [email, setEmail] = useState('');

    const { clearFlashes, addFlash } = useStoreActions((actions: Actions<ApplicationStore>) => actions.flashes);

    const parsed = new URLSearchParams(location.search);
    if (email.length === 0 && parsed.get('email')) {
        setEmail(parsed.get('email') || '');
    }

    const submit = ({ password, passwordConfirmation }: Values, { setSubmitting }: FormikHelpers<Values>) => {
        clearFlashes();
        performPasswordReset(email, { token: match.params.token, password, passwordConfirmation })
            .then(() => {
                // @ts-expect-error this is valid
                window.location = '/';
            })
            .catch((error) => {
                console.error(error);
                setSubmitting(false);
                addFlash({ type: 'error', title: 'Error', message: httpErrorToHuman(error) });
            });
    };

    return (
        <Formik
            onSubmit={submit}
            initialValues={{
                password: '',
                passwordConfirmation: '',
            }}
            validationSchema={object().shape({
                password: string()
                    .required('A new password is required.')
                    .min(8, 'Your new password should be at least 8 characters in length.'),
                passwordConfirmation: string()
                    .required('Your new password does not match.')
                    // @ts-expect-error this is valid
                    .oneOf([ref('password'), null], 'Your new password does not match.'),
            })}
        >
            {({ isSubmitting }) => (
                <LoginFormContainer title={'Reset Password'} css={tw`w-full flex flex-col`}>
                    <div>
                        <label css={tw`block text-xs uppercase text-neutral-500 mb-1 font-bold tracking-widest`}>
                            Email Address
                        </label>
                        <Input value={email} isLight disabled />
                    </div>
                    
                    <div css={tw`mt-6`}>
                        <Field
                            light
                            label={'New Password'}
                            name={'password'}
                            type={'password'}
                            description={'Passwords must be at least 8 characters in length.'}
                        />
                    </div>
                    
                    <div css={tw`mt-6`}>
                        <Field 
                            light 
                            label={'Confirm New Password'} 
                            name={'passwordConfirmation'} 
                            type={'password'} 
                        />
                    </div>
                    
                    <div css={tw`mt-8`}>
                        <Button 
                            size={'xlarge'} 
                            type={'submit'} 
                            disabled={isSubmitting} 
                            isLoading={isSubmitting}
                            css={tw`w-full shadow-[0 10px 15px -3px rgba(6, 182, 212, 0.25), 0 4px 6px -2px rgba(6, 182, 212, 0.1)]`}
                        >
                            Reset Password
                        </Button>
                    </div>

                    <div css={tw`mt-8 text-center`}>
                        <Link
                            to={'/auth/login'}
                            css={tw`text-xs text-neutral-500 tracking-wider uppercase no-underline hover:text-neutral-300 transition-colors duration-200`}
                        >
                            Return to Login
                        </Link>
                    </div>

                    {/* Premium Nexaura Branding Section */}
                    <div css={tw`mt-10 pt-6 border-t border-neutral-800/50 text-center`}>
                        <p css={tw`text-[10px] text-neutral-500 uppercase tracking-[0.3em] font-bold`}>
                            Made by <span css={tw`text-cyan-500`}>Nexaura</span>
                        </p>
                        <div css={tw`flex items-center justify-center space-x-2 mt-1.5`}>
                            <div css={tw`h-[1px] w-4 bg-neutral-800`} />
                            <p css={tw`text-[9px] text-neutral-600 uppercase tracking-[0.2em]`}>
                                Powered by Pterodactyl
                            </p>
                            <div css={tw`h-[1px] w-4 bg-neutral-800`} />
                        </div>
                    </div>
                </LoginFormContainer>
            )}
        </Formik>
    );
};