import React, { useEffect, useRef, useState } from 'react';
import { Link, RouteComponentProps } from 'react-router-dom';
import login from '@/api/auth/login';
import LoginFormContainer from '@/components/auth/LoginFormContainer';
import { useStoreState } from 'easy-peasy';
import { Formik, FormikHelpers } from 'formik';
import { object, string } from 'yup';
import Field from '@/components/elements/Field';
import tw from 'twin.macro';
import Button from '@/components/elements/Button';
import Reaptcha from 'reaptcha';
import useFlash from '@/plugins/useFlash';

interface Values {
    username: string;
    password: string;
}

const LoginContainer = ({ history }: RouteComponentProps) => {
    const ref = useRef<Reaptcha>(null);
    const [token, setToken] = useState('');

    const { clearFlashes, clearAndAddHttpError } = useFlash();
    const { enabled: recaptchaEnabled, siteKey } = useStoreState((state) => state.settings.data!.recaptcha);

    useEffect(() => {
        clearFlashes();
    }, []);

    const onSubmit = (values: Values, { setSubmitting }: FormikHelpers<Values>) => {
        clearFlashes();

        if (recaptchaEnabled && !token) {
            ref.current!.execute().catch((error) => {
                console.error(error);
                setSubmitting(false);
                clearAndAddHttpError({ error });
            });
            return;
        }

        login({ ...values, recaptchaData: token })
            .then((response) => {
                if (response.complete) {
                    // @ts-expect-error this is valid
                    window.location = response.intended || '/';
                    return;
                }
                history.replace('/auth/login/checkpoint', { token: response.confirmationToken });
            })
            .catch((error) => {
                console.error(error);
                setToken('');
                if (ref.current) ref.current.reset();
                setSubmitting(false);
                clearAndAddHttpError({ error });
            });
    };

    return (
        <Formik
            onSubmit={onSubmit}
            initialValues={{ username: '', password: '' }}
            validationSchema={object().shape({
                username: string().required('A username or email must be provided.'),
                password: string().required('Please enter your account password.'),
            })}
        >
            {({ isSubmitting, setSubmitting, submitForm }) => (
                <LoginFormContainer title={'Login to Continue'} css={tw`w-full flex flex-col`}>
                    <div css={tw`space-y-6`}>
                        <Field 
                            light 
                            type={'text'} 
                            label={'Username or Email'} 
                            name={'username'} 
                            disabled={isSubmitting} 
                        />
                        <Field 
                            light 
                            type={'password'} 
                            label={'Password'} 
                            name={'password'} 
                            disabled={isSubmitting} 
                        />
                    </div>

                    <div css={tw`mt-8`}>
                        <Button 
                            type={'submit'} 
                            size={'xlarge'} 
                            isLoading={isSubmitting} 
                            disabled={isSubmitting} 
                            /* Fix: Manual shadow definition to prevent "shadow-cyan-500/20 not found" error */
                            css={tw`w-full shadow-[0 10px 15px -3px rgba(6, 182, 212, 0.25), 0 4px 6px -2px rgba(6, 182, 212, 0.1)]`}
                        >
                            Login
                        </Button>
                    </div>

                    {recaptchaEnabled && (
                        <Reaptcha
                            ref={ref}
                            size={'invisible'}
                            sitekey={siteKey || '_invalid_key'}
                            onVerify={(response) => {
                                setToken(response);
                                submitForm();
                            }}
                            onExpire={() => {
                                setSubmitting(false);
                                setToken('');
                            }}
                        />
                    )}

                    <div css={tw`mt-8 text-center`}>
                        <Link
                            to={'/auth/password'}
                            css={tw`text-xs text-neutral-500 tracking-wider no-underline uppercase hover:text-neutral-300 transition-colors duration-200`}
                        >
                            Forgot password?
                        </Link>
                    </div>

                    {/* Premium Nexaura Branding Section */}
                    <div css={tw`mt-10 pt-6 border-t border-neutral-800/50 text-center`}>
                        <p css={tw`text-[10px] text-neutral-500 uppercase tracking-[0.3em] font-bold`}>
                            Made by <span css={tw`text-cyan-500`}>Nexaura</span>
                        </p>
                        <div css={tw`flex items-center justify-center space-x-2 mt-1.5`}>
                            <div css={tw`h-[1px] w-4 bg-neutral-800`} />
                            <p css={tw`text-[9px] text-neutral-600 uppercase tracking-[0.2em]`}>
                                Powered by Pterodactyl
                            </p>
                            <div css={tw`h-[1px] w-4 bg-neutral-800`} />
                        </div>
                    </div>
                </LoginFormContainer>
            )}
        </Formik>
    );
};

export default LoginContainer;