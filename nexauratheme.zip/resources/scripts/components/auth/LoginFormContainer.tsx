import React, { forwardRef } from 'react';
import { Form } from 'formik';
import styled, { keyframes } from 'styled-components/macro';
import { breakpoint } from '@/theme';
import FlashMessageRender from '@/components/FlashMessageRender';
import tw from 'twin.macro';

type Props = React.DetailedHTMLProps<React.FormHTMLAttributes<HTMLFormElement>, HTMLFormElement> & {
    title?: string;
};

const shimmer = keyframes`
    0% { transform: translateX(-100%) skewX(-15deg); }
    100% { transform: translateX(200%) skewX(-15deg); }
`;

const Container = styled.div`
    ${tw`flex flex-col items-center justify-center min-h-full w-full px-4`};

    ${breakpoint('sm')`
        ${tw`w-4/5 mx-auto`}
    `};

    ${breakpoint('md')`
        ${tw`p-10`}
    `};

    ${breakpoint('xl')`
        max-width: 950px;
    `};
`;

const GlassWrapper = styled.div`
    ${tw`flex flex-col md:flex-row w-full bg-neutral-900/40 border border-white/5 backdrop-blur-xl rounded-3xl overflow-hidden relative`};
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.7);
    
    &::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 1px;
        background: linear-gradient(90deg, transparent, rgba(6, 182, 212, 0.3), transparent);
    }
`;

const LogoArea = styled.div`
    ${tw`flex-none bg-white/[0.02] p-8 md:p-12 flex items-center justify-center border-b md:border-b-0 md:border-r border-white/5 relative overflow-hidden`};
    
    &::after {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 50%;
        height: 100%;
        background: linear-gradient(to right, transparent, rgba(255, 255, 255, 0.03), transparent);
        animation: ${shimmer} 4s infinite linear;
    }
`;

/* Created a styled img to handle the drop-shadow safely */
const StyledLogo = styled.img`
    ${tw`block w-32 md:w-44 z-10 opacity-90 transition-all duration-700`};
    filter: drop-shadow(0 0 15px rgba(6, 182, 212, 0.4));

    &:hover {
        ${tw`opacity-100 scale-110`};
        filter: drop-shadow(0 0 20px rgba(6, 182, 212, 0.6));
    }
`;

export default forwardRef<HTMLFormElement, Props>(({ title, ...props }, ref) => (
    <Container>
        {title && (
            <div css={tw`mb-10 text-center`}>
                <h2 css={tw`text-4xl md:text-5xl text-white font-black tracking-tighter`}>
                    {title}
                </h2>
                <div css={tw`flex items-center justify-center space-x-2 mt-4`}>
                    <div css={tw`h-[2px] w-8 bg-cyan-600 rounded-full`} />
                    <div css={tw`h-1.5 w-1.5 bg-cyan-400 rounded-full animate-pulse`} />
                    <div css={tw`h-[2px] w-8 bg-cyan-600 rounded-full`} />
                </div>
            </div>
        )}
        
        <FlashMessageRender css={tw`mb-6 w-full max-w-[800px] animate-pulse`} />
        
        <Form {...props} ref={ref} css={tw`w-full`}>
            <GlassWrapper>
                <LogoArea>
                    <StyledLogo 
                        src={'/assets/svgs/pterodactyl.svg'} 
                        alt="Logo"
                    />
                </LogoArea>

                <div css={tw`flex-1 p-8 md:p-14 bg-transparent z-10`}>
                    {props.children}
                </div>
            </GlassWrapper>
        </Form>

        <div css={tw`mt-12 text-center space-y-3 opacity-80`}>
            <div css={tw`flex items-center justify-center space-x-4`}>
                <div css={tw`h-px w-6 bg-neutral-800`} />
                <p css={tw`text-[11px] text-neutral-500 uppercase tracking-[0.4em] font-black`}>
                    Built by <span css={tw`text-cyan-500`}>Nexaura</span>
                </p>
                <div css={tw`h-px w-6 bg-neutral-800`} />
            </div>
            
            <p css={tw`text-[9px] text-neutral-600 uppercase tracking-widest font-medium`}>
                &copy; {new Date().getFullYear()} &bull; Optimized for 
                <a
                    rel={'noopener nofollow noreferrer'}
                    href={'https://pterodactyl.io'}
                    target={'_blank'}
                    css={tw`ml-1 no-underline text-neutral-400 hover:text-cyan-400 transition-colors duration-300 font-bold`}
                >
                    Pterodactyl
                </a>
            </p>
        </div>
    </Container>
));