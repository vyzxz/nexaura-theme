import React, { useState } from 'react';
import { Link, RouteComponentProps } from 'react-router-dom';
import loginCheckpoint from '@/api/auth/loginCheckpoint';
import LoginFormContainer from '@/components/auth/LoginFormContainer';
import { ActionCreator } from 'easy-peasy';
import { StaticContext } from 'react-router';
import { useFormikContext, withFormik } from 'formik';
import useFlash from '@/plugins/useFlash';
import { FlashStore } from '@/state/flashes';
import Field from '@/components/elements/Field';
import tw from 'twin.macro';
import Button from '@/components/elements/Button';

interface Values {
    code: string;
    recoveryCode: string;
}

type OwnProps = RouteComponentProps<Record<string, string | undefined>, StaticContext, { token?: string }>;

type Props = OwnProps & {
    clearAndAddHttpError: ActionCreator<FlashStore['clearAndAddHttpError']['payload']>;
};

const LoginCheckpointContainer = () => {
    const { isSubmitting, setFieldValue } = useFormikContext<Values>();
    const [isMissingDevice, setIsMissingDevice] = useState(false);

    const toggleMode = () => {
        setFieldValue('code', '');
        setFieldValue('recoveryCode', '');
        setIsMissingDevice((s) => !s);
    };

    return (
        <LoginFormContainer title={'Device Checkpoint'} css={tw`w-full flex flex-col`}>
            <div css={tw`mt-2`}>
                <Field
                    light
                    name={isMissingDevice ? 'recoveryCode' : 'code'}
                    label={isMissingDevice ? 'Recovery Code' : 'Authentication Code'}
                    description={
                        isMissingDevice
                            ? 'Enter a recovery code generated during setup to continue.'
                            : 'Enter the 6-digit token from your authenticator app.'
                    }
                    type={'text'}
                    autoComplete={'one-time-code'}
                    autoFocus
                />
            </div>

            <div css={tw`mt-8`}>
                <Button 
                    size={'xlarge'} 
                    type={'submit'} 
                    disabled={isSubmitting} 
                    isLoading={isSubmitting} 
                    /* Manual shadow fix to avoid twin.macro build errors */
                    css={tw`w-full shadow-[0 10px 15px -3px rgba(6, 182, 212, 0.25), 0 4px 6px -2px rgba(6, 182, 212, 0.1)]`}
                >
                    Continue
                </Button>
            </div>

            <div css={tw`mt-8 space-y-4 text-center`}>
                <div 
                    onClick={toggleMode}
                    css={tw`cursor-pointer text-xs text-cyan-400 font-bold tracking-wider uppercase hover:text-cyan-300 transition-colors duration-200`}
                >
                    {!isMissingDevice ? "I've Lost My Device" : 'I Have My Device'}
                </div>

                <div>
                    <Link
                        to={'/auth/login'}
                        css={tw`text-xs text-neutral-500 tracking-wider uppercase no-underline hover:text-neutral-300 transition-colors duration-200`}
                    >
                        Return to Login
                    </Link>
                </div>
            </div>

            {/* Premium Nexaura Branding Section */}
            <div css={tw`mt-10 pt-6 border-t border-neutral-800/50 text-center`}>
                <p css={tw`text-[10px] text-neutral-500 uppercase tracking-[0.3em] font-bold`}>
                    Made by <span css={tw`text-cyan-500`}>Nexaura</span>
                </p>
                <div css={tw`flex items-center justify-center space-x-2 mt-1.5`}>
                    <div css={tw`h-[1px] w-4 bg-neutral-800`} />
                    <p css={tw`text-[9px] text-neutral-600 uppercase tracking-[0.2em]`}>
                        Powered by Pterodactyl
                    </p>
                    <div css={tw`h-[1px] w-4 bg-neutral-800`} />
                </div>
            </div>
        </LoginFormContainer>
    );
};

const EnhancedForm = withFormik<Props, Values>({
    handleSubmit: ({ code, recoveryCode }, { setSubmitting, props: { clearAndAddHttpError, location } }) => {
        loginCheckpoint(location.state?.token || '', code, recoveryCode)
            .then((response) => {
                if (response.complete) {
                    // @ts-expect-error this is valid
                    window.location = response.intended || '/';
                    return;
                }
                setSubmitting(false);
            })
            .catch((error) => {
                console.error(error);
                setSubmitting(false);
                clearAndAddHttpError({ error });
            });
    },

    mapPropsToValues: () => ({
        code: '',
        recoveryCode: '',
    }),
})(LoginCheckpointContainer);

export default ({ history, location, ...props }: OwnProps) => {
    const { clearAndAddHttpError } = useFlash();

    if (!location.state?.token) {
        history.replace('/auth/login');
        return null;
    }

    return (
        <EnhancedForm clearAndAddHttpError={clearAndAddHttpError} history={history} location={location} {...props} />
    );
};