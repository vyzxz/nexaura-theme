import * as React from 'react';
import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import requestPasswordResetEmail from '@/api/auth/requestPasswordResetEmail';
import { httpErrorToHuman } from '@/api/http';
import LoginFormContainer from '@/components/auth/LoginFormContainer';
import { useStoreState } from 'easy-peasy';
import Field from '@/components/elements/Field';
import { Formik, FormikHelpers } from 'formik';
import { object, string } from 'yup';
import tw from 'twin.macro';
import Button from '@/components/elements/Button';
import Reaptcha from 'reaptcha';
import useFlash from '@/plugins/useFlash';

interface Values {
    email: string;
}

export default () => {
    const ref = useRef<Reaptcha>(null);
    const [token, setToken] = useState('');

    const { clearFlashes, addFlash } = useFlash();
    const { enabled: recaptchaEnabled, siteKey } = useStoreState((state) => state.settings.data!.recaptcha);

    useEffect(() => {
        clearFlashes();
    }, []);

    const handleSubmission = ({ email }: Values, { setSubmitting, resetForm }: FormikHelpers<Values>) => {
        clearFlashes();

        if (recaptchaEnabled && !token) {
            ref.current!.execute().catch((error) => {
                console.error(error);
                setSubmitting(false);
                addFlash({ type: 'error', title: 'Error', message: httpErrorToHuman(error) });
            });
            return;
        }

        requestPasswordResetEmail(email, token)
            .then((response) => {
                resetForm();
                addFlash({ type: 'success', title: 'Success', message: response });
            })
            .catch((error) => {
                console.error(error);
                addFlash({ type: 'error', title: 'Error', message: httpErrorToHuman(error) });
            })
            .then(() => {
                setToken('');
                if (ref.current) ref.current.reset();
                setSubmitting(false);
            });
    };

    return (
        <Formik
            onSubmit={handleSubmission}
            initialValues={{ email: '' }}
            validationSchema={object().shape({
                email: string()
                    .email('A valid email address must be provided to continue.')
                    .required('A valid email address must be provided to continue.'),
            })}
        >
            {({ isSubmitting, setSubmitting, submitForm }) => (
                <LoginFormContainer title={'Request Password Reset'} css={tw`w-full flex flex-col`}>
                    <Field
                        light
                        label={'Email Address'}
                        description={
                            'Enter your account email address to receive instructions on resetting your password.'
                        }
                        name={'email'}
                        type={'email'}
                    />
                    
                    <div css={tw`mt-8`}>
                        <Button 
                            type={'submit'} 
                            size={'xlarge'} 
                            disabled={isSubmitting} 
                            isLoading={isSubmitting}
                            css={tw`w-full shadow-[0 10px 15px -3px rgba(6, 182, 212, 0.25), 0 4px 6px -2px rgba(6, 182, 212, 0.1)]`}
                        >
                            Send Reset Email
                        </Button>
                    </div>

                    {recaptchaEnabled && (
                        <Reaptcha
                            ref={ref}
                            size={'invisible'}
                            sitekey={siteKey || '_invalid_key'}
                            onVerify={(response) => {
                                setToken(response);
                                submitForm();
                            }}
                            onExpire={() => {
                                setSubmitting(false);
                                setToken('');
                            }}
                        />
                    )}

                    <div css={tw`mt-8 text-center`}>
                        <Link
                            to={'/auth/login'}
                            css={tw`text-xs text-neutral-500 tracking-wider uppercase no-underline hover:text-neutral-300 transition-colors duration-200`}
                        >
                            Return to Login
                        </Link>
                    </div>

                    {/* Premium Nexaura Branding Section */}
                    <div css={tw`mt-10 pt-6 border-t border-neutral-800/50 text-center`}>
                        <p css={tw`text-[10px] text-neutral-500 uppercase tracking-[0.3em] font-bold`}>
                            Made by <span css={tw`text-cyan-500`}>Nexaura</span>
                        </p>
                        <div css={tw`flex items-center justify-center space-x-2 mt-1.5`}>
                            <div css={tw`h-[1px] w-4 bg-neutral-800`} />
                            <p css={tw`text-[9px] text-neutral-600 uppercase tracking-[0.2em]`}>
                                Powered by Pterodactyl
                            </p>
                            <div css={tw`h-[1px] w-4 bg-neutral-800`} />
                        </div>
                    </div>
                </LoginFormContainer>
            )}
        </Formik>
    );
};