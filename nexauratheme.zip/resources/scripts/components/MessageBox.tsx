import * as React from 'react';
import tw, { TwStyle } from 'twin.macro';
import styled from 'styled-components/macro';

export type FlashMessageType = 'success' | 'info' | 'warning' | 'error';

interface Props {
    title?: string;
    children: string;
    type?: FlashMessageType;
}

// --- Sector 07 Color Mapping ---
const THEME_MAP: Record<FlashMessageType, { border: string; bg: string; text: string; glow: string }> = {
    error: {
        border: 'border-red-500/40',
        bg: 'bg-red-500/5',
        text: 'text-red-400',
        glow: 'rgba(239, 68, 68, 0.2)',
    },
    success: {
        border: 'border-emerald-500/40',
        bg: 'bg-emerald-500/5',
        text: 'text-emerald-400',
        glow: 'rgba(16, 185, 129, 0.2)',
    },
    warning: {
        border: 'border-amber-500/40',
        bg: 'bg-amber-500/5',
        text: 'text-amber-400',
        glow: 'rgba(245, 158, 11, 0.2)',
    },
    info: {
        border: 'border-cyan-500/40',
        bg: 'bg-cyan-500/5',
        text: 'text-cyan-400',
        glow: 'rgba(6, 182, 212, 0.2)',
    },
};

const Container = styled.div<{ $type: FlashMessageType }>`
    ${tw`relative flex items-center p-3 border rounded-xl backdrop-blur-md transition-all duration-300 w-full text-sm font-bold` };
    
    ${({ $type }) => {
        const theme = THEME_MAP[$type];
        return `
            border-color: ${theme.border.replace('border-', '')};
            background-color: ${theme.bg.replace('bg-', '')};
            color: ${theme.text.replace('text-', '')};
            box-shadow: 0 0 15px ${theme.glow};
        `;
    }}

    /* The "Sector" side indicator */
    &::before {
        content: "";
        ${tw`absolute left-0 top-2 bottom-2 w-0.5 rounded-full` };
        background-color: ${({ $type }) => THEME_MAP[$type].text.replace('text-', '')};
    }
`;

const TitleTag = styled.span<{ $type: FlashMessageType }>`
    ${tw`flex items-center rounded px-2 py-0.5 text-[9px] font-black uppercase tracking-widest mr-4 leading-none border` };
    
    ${({ $type }) => {
        const theme = THEME_MAP[$type];
        return `
            border-color: ${theme.text.replace('text-', '')}33;
            background-color: ${theme.text.replace('text-', '')}15;
            color: ${theme.text.replace('text-', '')};
        `;
    }}
`;

const MessageBox = ({ title, children, type = 'info' }: Props) => (
    <Container $type={type} role={'alert'}>
        {title && (
            <TitleTag $type={type}>
                {title}
            </TitleTag>
        )}
        <span css={tw`text-left flex-auto uppercase tracking-tight text-[11px]`}>
            {children.replace(/ /g, '_')}
        </span>
        
        {/* Decorative corner element */}
        <div css={tw`absolute top-0 right-0 p-1 opacity-20`}>
            <div css={tw`w-1 h-1 border-t border-r border-current`} />
        </div>
    </Container>
);

export default MessageBox;