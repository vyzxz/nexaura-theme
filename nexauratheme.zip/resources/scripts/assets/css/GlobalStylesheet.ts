import tw from 'twin.macro';
import { createGlobalStyle, keyframes } from 'styled-components/macro';
// @ts-expect-error untyped font file
import font from '@fontsource-variable/ibm-plex-sans/files/ibm-plex-sans-latin-wght-normal.woff2';

const animateGradient = keyframes`
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
`;

const float = keyframes`
    0% { transform: translate(0, 0) scale(1); opacity: 0.3; }
    33% { transform: translate(50px, -80px) scale(1.2); opacity: 0.5; }
    66% { transform: translate(-30px, 40px) scale(0.8); opacity: 0.3; }
    100% { transform: translate(0, 0) scale(1); opacity: 0.3; }
`;

const gridScroll = keyframes`
    0% { background-position: 0 0; }
    100% { background-position: 40px 40px; }
`;

const fadeIn = keyframes`
    from { opacity: 0; filter: blur(10px); transform: scale(0.99); }
    to { opacity: 1; filter: blur(0); transform: scale(1); }
`;

export default createGlobalStyle`
    @font-face {
        font-family: 'IBM Plex Sans';
        font-style: normal;
        font-display: swap;
        font-weight: 100 700;
        src: url(${font}) format('woff2-variations');
        unicode-range: U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;
    }

    body {
        margin: 0;
        padding: 0;
        background-color: #02040a;
        ${tw`font-sans text-neutral-100 min-h-screen relative overflow-x-hidden`};
        letter-spacing: 0.015em;
        
        /* Layer 1: Animated Deep Space Mesh */
        background-image: linear-gradient(-45deg, #020617, #080a14, #1e1b4b, #020617);
        background-size: 400% 400%;
        animation: ${animateGradient} 15s ease-in-out infinite;
    }

    /* Layer 2: Infinite Cyber Grid */
    body::before {
        content: "";
        position: fixed;
        inset: 0;
        background-image: 
            linear-gradient(rgba(6, 182, 212, 0.04) 1px, transparent 1px),
            linear-gradient(90deg, rgba(6, 182, 212, 0.04) 1px, transparent 1px);
        background-size: 50px 50px;
        mask-image: radial-gradient(circle at center, black, transparent 90%);
        -webkit-mask-image: radial-gradient(circle at center, black, transparent 90%);
        animation: ${gridScroll} 30s linear infinite;
        pointer-events: none;
        z-index: 0;
    }

    /* Layer 3: Dynamic RGB Light Catchers */
    body::after {
        content: "";
        position: fixed;
        top: 10%;
        left: -10%;
        width: 80vw;
        height: 80vw;
        background: radial-gradient(circle, rgba(6, 182, 212, 0.08) 0%, rgba(79, 70, 229, 0.03) 40%, transparent 70%);
        border-radius: 50%;
        z-index: -1;
        filter: blur(120px);
        animation: ${float} 20s infinite ease-in-out;
    }

    #app {
        animation: ${fadeIn} 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        position: relative;
        z-index: 10;
    }

    /* Headers: Metallic Chrome with Glow */
    h1, h2, h3, h4, h5, h6 {
        ${tw`font-black tracking-tighter font-header uppercase`};
        background: linear-gradient(180deg, #FFFFFF 0%, #cbd5e1 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        filter: drop-shadow(0 0 15px rgba(6, 182, 212, 0.25));
    }

    p {
        ${tw`text-neutral-400 leading-relaxed font-sans`};
        text-shadow: 0 2px 4px rgba(0,0,0,0.3);
    }

    /* HUD Controls: Glassmorphism */
    input, textarea, select {
        background-color: rgba(0, 0, 0, 0.35);
        ${tw`border border-white/5 text-white placeholder-neutral-600 focus:border-cyan-500/60 transition-all duration-300 backdrop-blur-xl rounded-lg` };
        box-shadow: inset 0 2px 4px rgba(0,0,0,0.4);
        
        &:focus {
            box-shadow: 0 0 20px rgba(6, 182, 212, 0.1), inset 0 2px 4px rgba(0,0,0,0.4);
        }
    }

    /* Custom Selection Styling */
    ::selection {
        background-color: rgba(6, 182, 212, 0.99);
        color: #000;
    }

    /* Scrollbar: Cyber-Cyan Tube */
    ::-webkit-scrollbar {
        width: 5px;
    }

    ::-webkit-scrollbar-track {
        background: rgba(0, 0, 0, 0.3);
    }

    ::-webkit-scrollbar-thumb {
        background: linear-gradient(to bottom, #0891b2, #06b6d4, #0891b2);
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(6, 182, 212, 0.5);
    }

    /* Global Button Base */
    button {
        ${tw`active:scale-95 transition-all duration-200 select-none` };
        text-transform: uppercase;
        font-weight: 900;
        letter-spacing: 0.12em;
        text-shadow: 0 0 8px rgba(255,255,255,0.2);
    }
`;